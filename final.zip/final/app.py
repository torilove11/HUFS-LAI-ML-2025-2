import gradio as gr
import torch
import torch.nn as nn
import numpy as np
import joblib
from huggingface_hub import hf_hub_download
import warnings

# 시드 고정
torch.manual_seed(42)
np.random.seed(42)

# ==========================================
# 1. 스타일 (CSS) 정의
# ==========================================
APP_TITLE = "타격 지표 기반 타자 유형 분류 시스템"

CSS_CONTENT = """
<style>
#app_title { text-align: center; }
#app_title p {
    position: relative; display: inline-block;
    padding: 20px 40px; margin: 15px 0;
    font-family: 'Impact', sans-serif;
    font-size: 32px;
    font-weight: 900; line-height: 1.3;
    color: #36454F; -webkit-text-stroke: 0.5px rgba(255,255,255,0.25); text-shadow: none;
}
#app_title p::before {
    content: ""; position: absolute; inset: 0;
    border: 8px solid #36454F; outline: 3px solid white; outline-offset: -6px;
    border-radius: 12px; box-shadow: none; pointer-events: none;
}
button {
    background-color: #FFFFFF; border: 4px solid #36454F;
    font-size: 20px; padding: 15px 25px; transition: all 0.25s ease-in-out;
}
button:hover {
    background-color: #36454F; outline: 2px solid #36454F;
    outline-offset: 2px; transform: scale(1.05); cursor: pointer; color: #FFFFFF !important;
}
button:active { transform: scale(0.95); }
#input_panel, #output_panel {
    background-color: white !important; border: 2px solid #ccc !important;
    padding: 15px; border-radius: 6px;
}
#output_box textarea {
    font-size: 16px !important; line-height: 1.5 !important;
}
#examples_table { overflow-x: auto !important; }
#examples_table table { table-layout: fixed !important; width: 100% !important; min-width: 1200px !important; }
#examples_table table th, #examples_table table td {
    white-space: nowrap !important; text-align: center !important;
    overflow: hidden; text-overflow: ellipsis; padding: 8px 4px !important;
}
</style>
"""

# ==========================================
# 2. 모델 정의 및 로드
# ==========================================
class BatterTypeClassifier(nn.Module):
    def __init__(self):
        super(BatterTypeClassifier, self).__init__()
        self.layer1 = nn.Linear(5, 64)
        self.relu = nn.ReLU()
        self.dropout = nn.Dropout(0.3)
        self.layer2 = nn.Linear(64, 32)
        self.layer3 = nn.Linear(32, 3)

    def forward(self, x):
        x = self.relu(self.layer1(x))
        x = self.dropout(x)
        x = self.relu(self.layer2(x))
        x = self.layer3(x)
        return x

model = None
scaler = None
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

try:
    repo_id = "ohsj611/batter_classifier"
    model_path = hf_hub_download(repo_id=repo_id, filename="best_batter_classifier.pth")
    scaler_path = hf_hub_download(repo_id=repo_id, filename="scaler.pkl")

    model = BatterTypeClassifier()
    checkpoint = torch.load(model_path, map_location=device)
    model.load_state_dict(checkpoint)
    model.to(device)
    model.eval()

    scaler = joblib.load(scaler_path)
    print("✅ 모델 로드 성공")
except Exception as e:
    print(f"❌ 오류 발생: {e}")

# ==========================================
# 3. 예측 함수
# ==========================================
def predict(name, year, pa, ab, h, d2, d3, hr, so, bb):
    if model is None or scaler is None:
        return "❌ 오류: 모델이 로드되지 않았습니다."

    if any(val is None for val in [pa, ab, h, d2, d3, hr, so, bb]):
        return "❌ 오류: 모든 값을 입력해주세요."
    if any(val < 0 for val in [pa, ab, h, d2, d3, hr, so, bb]):
        return "❌ 오류: 모든 지표는 0 이상이어야 합니다."
    if pa < 50:
        return "❌ 오류: 타석(PA)이 50 미만입니다."
    if ab == 0:
        return "❌ 오류: 타수(AB)가 0입니다."

    h_ratio = h / ab
    xb_ratio = (d2 + d3) / ab
    hr_ratio = hr / ab
    so_ratio = so / pa
    bb_ratio = bb / pa

    raw_features = np.array([[h_ratio, xb_ratio, hr_ratio, so_ratio, bb_ratio]])
    scaled_features = scaler.transform(raw_features)
    inputs = torch.FloatTensor(scaled_features).to(device)

    with torch.no_grad():
        outputs = model(inputs)
        probs = torch.nn.functional.softmax(outputs, dim=1)
        _, predicted_idx = torch.max(outputs, 1)
        type_idx = predicted_idx.item()

    types = ['GAP', 'POWER', 'CONTACT']
    result_type = types[type_idx]
    confidence = probs[0][type_idx].item() * 100

    res = "="*50 + "\n"
    res += f"{name} ({year})\n"
    res += "="*50 + "\n"

    if result_type == 'POWER':
        res += f"\n타격 유형: POWER HITTER\n"
        res += f"육성 가이드: 파워 능력치에 집중 투자하세요!\n"
        res += f"추천 포인트 분배: 파워 15 / 컨택 4 / 선구 1\n"
    elif result_type == 'GAP':
        res += f"\n타격 유형: GAP HITTER\n"
        res += f"육성 가이드: 컨택을 중심으로 밸런스를 맞추세요.\n"
        res += f"추천 포인트 분배: 파워 5 / 컨택 10 / 선구 5\n"
    else:
        res += f"\n타격 유형: CONTACT HITTER\n"
        res += f"육성 가이드: 정확한 타격과 선구안에 올인하세요.\n"
        res += f"추천 포인트 분배: 파워 1 / 컨택 10 / 선구 9\n"

    res += "\n" + "="*50
    return res

# ==========================================
# 4. UI 구성 (Gradio)
# ==========================================
def build_ui() -> gr.Blocks:
    with gr.Blocks(title=APP_TITLE) as demo:
        gr.HTML(CSS_CONTENT)

        gr.Markdown("타격 지표 기반 타자의 타격 유형 자동 분류를 통한 이사만루 육성 가이드 시스템", elem_id="app_title")

        with gr.Row():
            # Left: Inputs
            with gr.Column(elem_id="input_panel"):
                gr.Markdown("### 타격 지표")
                with gr.Row():
                    in_name = gr.Textbox(label="이름", placeholder="예: 이정후")
                    in_year = gr.Textbox(label="연도", placeholder="예: 2023")

                # [수정] value=None 유지 + interactive=True 추가 (초기화 강제)
                with gr.Row():
                    in_pa = gr.Number(label="타석 (PA)", value=None, placeholder="예: 627", interactive=True)
                    in_ab = gr.Number(label="타수 (AB)", value=None, placeholder="예: 553", interactive=True)
                with gr.Row():
                    in_h = gr.Number(label="안타 (H)", value=None, placeholder="예: 193", interactive=True)
                    in_2b = gr.Number(label="2루타 (2B)", value=None, placeholder="예: 36", interactive=True)
                with gr.Row():
                    in_3b = gr.Number(label="3루타 (3B)", value=None, placeholder="예: 10", interactive=True)
                    in_hr = gr.Number(label="홈런 (HR)", value=None, placeholder="예: 23", interactive=True)
                with gr.Row():
                    in_so = gr.Number(label="삼진 (SO)", value=None, placeholder="예: 32", interactive=True)
                    in_bb = gr.Number(label="볼넷 (BB)", value=None, placeholder="예: 66", interactive=True)

                with gr.Row():
                    run_btn = gr.Button("분석", scale=3, variant="primary")
                    clear_btn = gr.Button("재설정", scale=1)

            # Right: Output
            with gr.Column(elem_id="output_panel"):
                gr.Markdown("### 분석 결과")
                out_result = gr.Textbox(label="Result", show_label=False, lines=10, elem_id="output_box")

                gr.Examples(
                    examples=[
                        ["양석환", "2024", 593, 533, 131, 25, 1, 34, 128, 49],
                        ["손아섭", "2023", 609, 551, 187, 36, 3, 5, 58, 46],
                        ["구자욱", "2023", 508, 453, 152, 37, 1, 11, 69, 43]
                    ],
                    inputs=[in_name, in_year, in_pa, in_ab, in_h, in_2b, in_3b, in_hr, in_so, in_bb],
                    label="예시",
                    elem_id="examples_table"
                )

        run_btn.click(
            predict,
            inputs=[in_name, in_year, in_pa, in_ab, in_h, in_2b, in_3b, in_hr, in_so, in_bb],
            outputs=[out_result]
        )

        clear_btn.click(
            lambda: [None] * 11,
            inputs=None,
            outputs=[in_name, in_year, in_pa, in_ab, in_h, in_2b, in_3b, in_hr, in_so, in_bb, out_result]
        )

    return demo

if __name__ == "__main__":
    demo = build_ui()
    demo.launch()