import streamlit as st
import pandas as pd
import joblib
import os
import numpy as np

# --- 1. 페이지 설정 ---
st.set_page_config(
    page_title="Logan Allen 투구 예측",
    page_icon="⚾",
    layout="centered"
)

# --- 2. 모델 로드 함수 (캐싱 사용으로 속도 향상) ---
@st.cache_resource
def load_model():
    # 현재 파일(app.py)이 있는 위치를 기준으로 경로 설정
    current_dir = os.path.dirname(os.path.abspath(__file__))
    model_path = os.path.join(current_dir, 'pitcher_model.pkl')
    encoder_path = os.path.join(current_dir, 'pitch_type_encoder.pkl')
    
    if not os.path.exists(model_path) or not os.path.exists(encoder_path):
        return None, None
    
    model = joblib.load(model_path)
    encoder = joblib.load(encoder_path)
    return model, encoder

model, le = load_model()

# --- 3. UI 디자인 ---
st.title("⚾ Logan Allen 투구 예측 봇")
st.markdown("### 현재 경기 상황을 입력하면 다음 구종을 예측합니다!")

if model is None:
    st.error("🚨 모델 파일(.pkl)을 찾을 수 없습니다. 같은 폴더에 파일이 있는지 확인해주세요.")
    st.stop()

# --- 4. 사용자 입력 받기 (사이드바 또는 메인 화면) ---
with st.container():
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("📊 볼카운트 & 이닝")
        inning = st.number_input("이닝 (Inning)", min_value=1, max_value=20, value=1)
        balls = st.selectbox("볼 (Balls)", [0, 1, 2, 3])
        strikes = st.selectbox("스트라이크 (Strikes)", [0, 1, 2])
        outs = st.selectbox("아웃 (Outs)", [0, 1, 2])

    with col2:
        st.subheader("🏃 주자 상황")
        on_1b = st.checkbox("1루 주자 있음", value=False)
        on_2b = st.checkbox("2루 주자 있음", value=False)
        on_3b = st.checkbox("3루 주자 있음", value=False)

# 입력값을 모델에 맞게 변환 (True/False -> 1/0)
input_data = pd.DataFrame({
    'balls': [balls],
    'strikes': [strikes],
    'on_1b': [1 if on_1b else 0],
    'on_2b': [1 if on_2b else 0],
    'on_3b': [1 if on_3b else 0],
    'outs_when_up': [outs],
    'inning': [inning]
})

# --- 5. 예측 실행 및 결과 표시 ---
if st.button("🔮 다음 공 예측하기", type="primary"):
    
    # 예측 수행
    prediction_idx = model.predict(input_data)[0]
    prediction_name = le.inverse_transform([prediction_idx])[0]
    probabilities = model.predict_proba(input_data)[0]
    
    # 구종 설명 매핑 (선택 사항)
    pitch_desc = {
        'FF': '직구 (4-Seam Fastball) 💨',
        'CH': '체인지업 (Changeup) 🍂',
        'ST': '스위퍼 (Sweeper) ↔️',
        'FC': '커터 (Cutter) ✂️',
        'SI': '싱커 (Sinker) ↘️',
        'FS': '스플리터 (Splitter) ⬇️'
    }
    
    full_name = pitch_desc.get(prediction_name, prediction_name)

    # 결과 출력
    st.divider()
    st.success(f"### 예측 결과: **{full_name}**")
    
    # 확률 차트 그리기
    st.write("#### 📈 구종별 확률 분포")
    
    # 확률 데이터프레임 생성
    prob_df = pd.DataFrame({
        '구종': le.classes_,
        '확률': probabilities
    }).set_index('구종')
    
    # 차트 출력
    st.bar_chart(prob_df)
    
    # 확률표 자세히 보기
    with st.expander("상세 확률 보기"):
        st.dataframe(prob_df.style.format("{:.2%}"))

# --- 6. 하단 정보 ---
st.markdown("---")
st.caption("Developed by 202401765 (Assignment 6 Project)")