````markdown
# 📅 [HUFS-LAI ML 2025-2 Assignment 6] OCR 기반 캡처 이미지 일정 누적 등록 도구

## 1. 프로젝트 개요 (Project Overview)

본 프로젝트는 메신저(카카오톡, 슬랙 등)에서 공유된 **캡처 이미지** 내의 일정 정보를 자동으로 추출하고, 여러 이미지에서 추출된 일정을 **하나의 캘린더 파일(.ics)**로 통합하여 사용자에게 제공하는 도구입니다.

* **문제 해결:** 일정 공지 캡처 이미지를 수동으로 캘린더에 입력해야 하는 비효율성과 오기입 문제를 해소합니다.
* **핵심 기능:**
    1.  Tesseract OCR을 이용한 이미지-텍스트 변환.
    2.  한국어 정규식을 이용한 날짜 및 시간 정보 파싱 (시간 정보가 없어도 날짜만 추출하여 종일 이벤트로 등록 가능).
    3.  여러 이미지를 처리하여 추출된 일정을 하나의 `.ics` 파일로 누적 및 통합.
* **서비스 형태:** Google Colab 환경에서 실행되는 Python 기반의 **CLI (Command Line Interface)** 도구.

## 2. 모델 및 기술 스택 (Model and Technology Stack)

| 구분 | 기술/도구 | 역할 |
| :--- | :--- | :--- |
| **핵심 모델** | Tesseract OCR Engine (v4.x) | 이미지에서 텍스트를 인식 및 추출 |
| **후처리** | Python RegEx (re 모듈) | 추출된 텍스트에서 날짜/시간 패턴 파싱 |
| **캘린더 포맷** | `ics` 라이브러리 | 표준 `.ics` (iCalendar) 파일 생성 |
| **실행 환경** | Google Colab, Python 3.x | 서버 구축 없이 실행 가능한 환경 제공 |

## 3. 실행 환경 설정 (Setup and Installation)

본 도구는 Google Colab 노트북에서 실행하도록 최적화되어 있습니다.

### 3.1. 요구 사항

* Python 3.x 환경
* Google Colab 계정

### 3.2. 실행 전 설치 (Colab 첫 번째 셀에 포함됨)

실행을 위해 Tesseract OCR 엔진과 필요한 Python 라이브러리를 설치해야 합니다.

```bash
# Tesseract OCR 엔진 및 한글 팩 설치
!sudo apt-get update
!sudo apt-get install tesseract-ocr tesseract-ocr-kor -y

# Python 라이브러리 설치
!pip install pytesseract ics Pillow
````

## 4\. 도구 사용 방법 (How to Use)

모든 코드는 Colab 노트북에 순서대로 붙여넣고 실행하는 것을 전제로 합니다.

### 단계 1: 환경 설정 및 함수 정의

1.  제출된 코드를 Colab에 붙여넣습니다.
2.  첫 번째 셀 (Tesseract 설치)과 두 번째 셀 (함수 정의)을 순서대로 실행합니다.

### 단계 2: 일정 누적 및 처리

세 번째 셀에 있는 `process_multiple_uploads_final()` 함수를 실행합니다.

1.  **반복 업로드:** 스크립트가 실행되면 파일 업로드 창이 뜨고, 캡처 이미지를 하나씩 선택하여 업로드합니다.
2.  **누적 확인:** 업로드할 때마다 추출된 일정 제목과 시간이 콘솔에 출력되며, \*\*[현재 누적된 일정 수]\*\*가 증가합니다.
3.  **종료 및 다운로드:** 모든 이미지를 업로드한 후, 마지막 파일 선택 창에서 \*\*`취소`\*\*를 누르면 프로그램이 일정을 통합하고 **`accumulated_schedule_tesseract.ics`** 파일을 자동으로 다운로드합니다.

## 5\. 최종 서비스 구조 (Final Service Architecture)

서비스는 순차적인 명령어 실행 흐름(CLI)을 따르며, 학습된 ML 모델(Tesseract)이 핵심 데이터 변환을 담당합니다.

1.  **사용자 입력:** Colab `files.upload()`를 통해 이미지 파일 입력.
2.  **ML 모델 (Tesseract):** 이미지 파일을 텍스트 문자열로 변환.
3.  **파싱 로직:** Python 정규식(`re` 모듈)이 텍스트에서 날짜/시간 패턴을 찾아 `datetime` 객체로 변환.
4.  **ICS 생성:** `ics` 라이브러리가 파싱된 모든 일정을 통합하여 하나의 `.ics` 파일을 구성.
5.  **결과 출력:** `files.download()`를 통해 사용자에게 최종 파일 전달.

-----

```
```