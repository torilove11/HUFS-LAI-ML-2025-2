# service_cli.py
import os
import csv
import datetime

from ocr_model import run_receipt_ocr  # 아래에서 만들 함수 이름과 같아야 함

LOG_PATH = "records.csv"


def ensure_log_file():
    """records.csv가 없으면 헤더를 가진 새 파일 생성"""
    if not os.path.exists(LOG_PATH):
        with open(LOG_PATH, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(
                ["timestamp", "image_path", "raw_output", "json_text", "date", "store", "total"]
            )


def main():
    print("=== 영수증 Donut OCR CLI 서비스 ===")
    print("이미지 경로를 입력하면 date / store / total 을 추출합니다.")
    print("종료하려면 q 를 입력하세요.\n")

    ensure_log_file()

    while True:
        path = input("분석할 영수증 이미지 경로를 입력하세요 (q: 종료): ").strip().strip('"')

        if path.lower() in {"q", "quit", "exit"}:
            print("서비스를 종료합니다.")
            break

        if not os.path.exists(path):
            print("해당 경로에 파일이 없습니다. 다시 입력해주세요.\n")
            continue

        try:
            raw, json_text, parsed = run_receipt_ocr(path)
        except Exception as e:
            print("모델 추론 중 오류가 발생했습니다:", e)
            continue

        print("\nRAW OUTPUT:", raw)
        if json_text is None:
            print("JSON을 찾지 못했습니다")
        else:
            print("JSON TEXT:", json_text)
            print("파싱 결과:", parsed)

        # 로그 저장
        now = datetime.datetime.now().isoformat(timespec="seconds")
        date = parsed.get("date", "") if parsed else ""
        store = parsed.get("store", "") if parsed else ""
        total = parsed.get("total", "") if parsed else ""

        with open(LOG_PATH, "a", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow([now, path, raw, json_text or "", date, store, total])

        print("records.csv에 사용 기록을 저장했습니다.\n")


if __name__ == "__main__":
    main()
