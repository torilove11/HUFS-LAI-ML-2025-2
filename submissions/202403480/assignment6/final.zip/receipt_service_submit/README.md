0. Donut 모델 다운로드
- fine-tune된 Donut 모델(`donut_finetuned` 폴더)은 용량이 커서 final.zip에 포함하지 않았습니다.
- 아래 링크에서 `donut_finetuned.zip` 을 다운로드한 뒤, 압축을 풀어서 `receipt_service/donut_finetuned` 경로에 그대로 넣어야 합니다.
- 다운로드 링크: https://drive.google.com/drive/folders/18Pf-XIzzRGwvKJ959rGuFMwzib034B9w?usp=drive_link

1. 환경 준비 
1) `final.zip` 압축을 해제
2) 터미널(Git Bash 등)에서 `receipt_service` 폴더로 이동 (bash에서 cd receipt_service 입력)
3) Python 3.10 이상 권장
4) 패키지 설치: pip install -r requirements.txt

2. 환경 변수(.env) 설정
1) 봇을 하나 만들고, 발급받은 토큰을 .env에 입력 (DISCORD_TOKEN=디스코드 봇 토큰)

3. Discord 가계부 봇 실행
1) 터미널(Git Bash 등)에서 봇 실행 (bash에서 cd receipt_service 입력, python discord_bot.py 입력)
2) 영수증 이미지 디스코드 봇에 보내서 실사용 

4. 가계부 조회 
1) !가계부, !이번주, !오늘 명령어를 DM에 보내 각각 전체, 주간, 당일 가계부를 확인



