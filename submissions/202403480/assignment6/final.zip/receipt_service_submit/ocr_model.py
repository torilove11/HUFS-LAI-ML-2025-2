# ocr_model.py
"""
Donut 파인튜닝 모델 로드 + 영수증 OCR 함수

- load_ocr_model(device="cpu" or "cuda")
- run_ocr(image_path, processor, model, device)
- run_receipt_ocr(image_path)  # service_cli.py / discord_bot.py 에서 사용
"""

import json
import re
import os

import torch
from PIL import Image
from transformers import DonutProcessor, VisionEncoderDecoderModel

# 파인튜닝 결과 폴더
MODEL_DIR = "donut_finetuned"
MAX_LENGTH = 80

# 캐싱용 전역 변수
_PROCESSOR = None
_MODEL = None
_DEVICE = None


def load_ocr_model(device: str = "cpu"):
    """
    Donut Processor + Model + device 를 로드해서 반환.
    device 인자는 "cpu" 또는 "cuda".
    """
    global _PROCESSOR, _MODEL, _DEVICE

    # 이미 로드되어 있으면 그대로 반환
    if _PROCESSOR is not None and _MODEL is not None and _DEVICE is not None:
        return _PROCESSOR, _MODEL, _DEVICE

    # device 선택
    if device == "cuda":
        if torch.cuda.is_available():
            device_name = "cuda"
        else:
            print("[ocr_model] cuda 선택했지만 GPU 가 없어서 cpu 로 사용합니다.")
            device_name = "cpu"
    else:
        device_name = "cpu"

    _DEVICE = torch.device(device_name)

    print(f"[ocr_model] MODEL_DIR = {MODEL_DIR}")
    _PROCESSOR = DonutProcessor.from_pretrained(MODEL_DIR)
    _MODEL = VisionEncoderDecoderModel.from_pretrained(MODEL_DIR)

    _MODEL.to(_DEVICE)
    _MODEL.eval()

    print(f"[ocr_model] 모델 로드 완료 (device={_DEVICE})")
    return _PROCESSOR, _MODEL, _DEVICE


def _decode_and_parse(processor: DonutProcessor, generated_ids) -> tuple[str, str, dict]:
    """
    Donut generate 결과를 문자열로 디코딩하고, 그 안에서 JSON 부분을 찾아 파싱.
    generated_ids : model.generate(...) 가 반환한 tensor 또는 list
    """
    # batch_decode는 tensor/list 둘 다 처리 가능
    sequence = processor.batch_decode(generated_ids)[0]

    # EOS / PAD 토큰 제거
    sequence = sequence.replace(processor.tokenizer.eos_token, "")
    sequence = sequence.replace(processor.tokenizer.pad_token, "")
    sequence = sequence.strip()

    raw_output = sequence

    # 중괄호 부분만 추출해서 JSON 파싱 시도
    json_text = ""
    parsed: dict = {}

    m = re.search(r"\{.*\}", sequence)
    if m:
        json_text = m.group(0)
        try:
            parsed = json.loads(json_text)
        except Exception as e:
            print("[ocr_model] JSON 파싱 실패:", repr(e))
    else:
        json_text = "JSON을 찾지 못했어요 ㅠㅠ"

    result = {
        "date": parsed.get("date"),
        "store": parsed.get("store"),
        "total": parsed.get("total"),
    }

    return raw_output, json_text, result


def run_ocr(image_path: str, processor=None, model=None, device=None):
    """
    단일 이미지에 대해 OCR 수행.
    processor / model / device 가 없으면 내부에서 load_ocr_model() 호출.
    """
    if processor is None or model is None or device is None:
        processor, model, device = load_ocr_model(device="cpu")

    if not os.path.exists(image_path):
        raise FileNotFoundError(f"이미지 파일을 찾을 수 없습니다: {image_path}")

    image = Image.open(image_path).convert("RGB")

    pixel_values = processor(image, return_tensors="pt").pixel_values.to(device)

    with torch.no_grad():
        # return_dict_in_generate=False 이면 tensor 그대로 반환
        generated_ids = model.generate(
            pixel_values,
            max_length=MAX_LENGTH,
            num_beams=1,
            return_dict_in_generate=False,
        )

    raw_output, json_text, parsed = _decode_and_parse(processor, generated_ids)
    return raw_output, json_text, parsed


def run_receipt_ocr(image_path: str):
    """
    CLI/디스코드 공용: 영수증 한 장 OCR.
    """
    processor, model, device = load_ocr_model(device="cpu")
    return run_ocr(image_path, processor, model, device)
