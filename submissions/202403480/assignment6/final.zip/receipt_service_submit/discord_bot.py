# discord_bot.py
# 영수증 이미지를 보내면
# 1) Donut OCR로 날짜 / 가게 / 금액 추정
# 2) vendor_map.csv + 규칙으로 카테고리 추정
# 3) 임베드 + "확정(저장)" / "수정" 버튼 제공
# 4) ledger.csv 에 category,cost,date,store 형태로 저장 (항상 날짜 오름차순으로 유지)
# 5) !가계부 / !오늘 / !이번주 명령어로 가계부 요약 조회

import os
import csv
import asyncio
from datetime import datetime, date, timedelta
from uuid import uuid4

import discord
from discord.ext import commands
from dotenv import load_dotenv

from ocr_model import load_ocr_model, run_ocr  # 우리가 만든 OCR 모듈

# ===== .env 에서 토큰 읽기 =====
load_dotenv()
DISCORD_TOKEN = os.getenv("DISCORD_TOKEN")
if not DISCORD_TOKEN:
    raise RuntimeError("DISCORD_TOKEN 이 .env 에 설정되어 있지 않습니다!")

# ===== 기본 설정 =====
LEDGER_FILE = "ledger.csv"        # 가계부 CSV
TMP_DIR = "tmp_images"            # 디스코드 이미지 임시 저장 폴더
VENDOR_MAP_FILE = "vendor_map.csv"

os.makedirs(TMP_DIR, exist_ok=True)

# 사용할 카테고리들
BASE_CATEGORIES = ["편의점/마트", "카페", "식비", "배달", "의료/약국", "기타"]

intents = discord.Intents.default()
intents.message_content = True  # DMs / 일반 채널 메시지 내용 읽기

bot = commands.Bot(command_prefix="!", intents=intents)


# ---------------------------------------------------------
#  Vendor Map 로드 (keyword -> category)
# ---------------------------------------------------------
def load_vendor_map(path: str):
    mapping = []
    if not os.path.exists(path):
        return mapping

    # utf-8-sig 로 BOM 제거
    with open(path, "r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            key = (row.get("keyword") or "").strip().lower()
            cat = (row.get("category") or "").strip()
            if not key or not cat:
                continue
            if cat not in BASE_CATEGORIES:
                # 잘못된 카테고리명이면 기타 처리
                cat = "기타"
            mapping.append((key, cat))
    return mapping


VENDOR_MAP = load_vendor_map(VENDOR_MAP_FILE)


def guess_category(store_name: str, raw_text: str) -> str:
    """vendor_map.csv + 간단 키워드 규칙으로 카테고리 추측"""

    text = f"{store_name} {raw_text}".lower()

    # 1) vendor_map.csv 우선
    for key, cat in VENDOR_MAP:
        if key in text:
            return cat

    # 2) 간단 규칙
    rule_keywords = {
        "cu": "편의점/마트",
        "gs25": "편의점/마트",
        "emart": "편의점/마트",
        "마트": "편의점/마트",
        "편의점": "편의점/마트",
        "starbucks": "카페",
        "카페": "카페",
        "요기요": "배달",
        "배달": "배달",
        "배민": "배달",
        "약국": "의료/약국",
        "병원": "의료/약국",
    }

    for kw, cat in rule_keywords.items():
        if kw in text:
            return cat

    return "기타"


# ---------------------------------------------------------
#  ledger.csv (항상 날짜 오름차순 유지)
#  컬럼: category, cost, date, store
# ---------------------------------------------------------
def ensure_ledger_file():
    """ledger.csv 가 없으면 새로 생성 (헤더 포함)"""
    if os.path.exists(LEDGER_FILE):
        return
    with open(LEDGER_FILE, "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=["category", "cost", "date", "store"],
        )
        writer.writeheader()


def _parse_date_for_sort(date_str: str):
    """YYYY-MM-DD 형식의 날짜 문자열을 정렬용 키로 변환"""
    try:
        # '2025-12-09 13:45' 처럼 시간이 붙어 있어도 앞 10자리만 사용
        return datetime.strptime(date_str[:10], "%Y-%m-%d")
    except Exception:
        # 이상한 날짜는 맨 뒤로 가도록 아주 큰 값 반환
        return datetime.max


def save_receipt_row(data: dict):
    """
    새 영수증 한 건을 ledger.csv 에 저장.
    저장할 때마다 전체를 날짜 오름차순으로 정렬해서 덮어쓴다.
    """
    ensure_ledger_file()

    # 1) 새로 추가할 행 정리
    try:
        cost_val = int(str(data.get("cost", 0)).replace(",", ""))
    except Exception:
        cost_val = 0

    new_row = {
        "category": data.get("category", "기타"),
        "cost": cost_val,
        "date": data.get("date", "") or "",
        "store": data.get("store", "") or "",
    }

    # 2) 기존 행들 읽기
    rows = []
    with open(LEDGER_FILE, "r", encoding="utf-8", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            try:
                c = int(str(row.get("cost", "0")).replace(",", ""))
            except Exception:
                c = 0
            rows.append(
                {
                    "category": row.get("category", "") or "기타",
                    "cost": c,
                    "date": row.get("date", "") or "",
                    "store": row.get("store", "") or "",
                }
            )

    # 3) 새 행 추가
    rows.append(new_row)

    # 4) 날짜 기준으로 정렬
    rows.sort(key=lambda r: _parse_date_for_sort(r["date"]))

    # 5) 전체를 다시 write (헤더 포함)
    with open(LEDGER_FILE, "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=["category", "cost", "date", "store"],
        )
        writer.writeheader()
        for r in rows:
            writer.writerow(r)


def load_ledger_rows():
    """ledger.csv 전체 행을 리스트로 읽어서 반환 (이미 날짜 순이긴 하지만, 한 번 더 정렬)"""
    if not os.path.exists(LEDGER_FILE):
        return []

    rows = []
    with open(LEDGER_FILE, "r", encoding="utf-8", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            try:
                cost = int(str(row.get("cost", "0")).replace(",", ""))
            except Exception:
                cost = 0
            rows.append(
                {
                    "category": row.get("category", "") or "기타",
                    "cost": cost,
                    "date": row.get("date", "") or "",
                    "store": row.get("store", "") or "",
                }
            )

    rows.sort(key=lambda r: _parse_date_for_sort(r["date"]))
    return rows


async def send_summary(ctx, rows, title: str):
    """공통 요약 메시지 생성 & 전송"""
    if not rows:
        await ctx.send("해당 기간에 해당하는 지출 내역이 없어요.")
        return

    total = sum(r["cost"] for r in rows)

    # 카테고리별 합계
    by_cat = {}
    for r in rows:
        cat = r["category"] or "기타"
        by_cat[cat] = by_cat.get(cat, 0) + r["cost"]

    lines = []
    lines.append(f"📒 **{title}**")
    lines.append(f"총 지출: **{total:,}원**\n")

    lines.append("카테고리별 지출:")
    for cat, amount in sorted(by_cat.items(), key=lambda x: -x[1]):
        ratio = amount / total if total else 0
        bar = "▇" * int(ratio * 10)  # 간단한 막대 그래프
        lines.append(
            f"- {cat:<8}: {amount:>7,}원  ({ratio*100:5.1f}%) {bar}"
        )

    # 최근 5건 내역
    recent = rows[-5:]
    lines.append("\n최근 5건:")
    for r in recent:
        lines.append(
            f"- {r['date']}  {r['store'] or '-':<10}  {r['cost']:,}원 ({r['category']})"
        )

    await ctx.send("\n".join(lines))


# ---------------------------------------------------------
#  Discord View (버튼)
# ---------------------------------------------------------
class ReceiptView(discord.ui.View):
    def __init__(self, bot: commands.Bot, ocr_data: dict, owner_id: int):
        super().__init__(timeout=300)  # 5분
        self.bot = bot
        self.ocr_data = ocr_data
        self.owner_id = owner_id

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        # 영수증을 보낸 사람만 버튼 사용
        if interaction.user.id != self.owner_id:
            await interaction.response.send_message(
                "이 영수증의 작성자만 버튼을 사용할 수 있습니다.", ephemeral=True
            )
            return False
        return True

    @discord.ui.button(label="확정(저장)", style=discord.ButtonStyle.success)
    async def confirm_button(
        self, interaction: discord.Interaction, button: discord.ui.Button
    ):
        save_receipt_row(self.ocr_data)
        await interaction.response.send_message(
            "가계부에 저장했어요!", ephemeral=True
        )
        self.stop()

    @discord.ui.button(label="수정", style=discord.ButtonStyle.secondary)
    async def edit_button(
        self, interaction: discord.Interaction, button: discord.ui.Button
    ):
        # 수정 가이드 전송
        await interaction.response.send_message(
            "수정할 값을 아래 형식으로 보내 주세요.\n"
            "`날짜, 카테고리, 금액, 업체명`\n"
            "업체명은 생략 가능해요.\n"
            "예시: `2025-12-10, 식비, 8300, 알촌`",
            ephemeral=True,
        )

        def check(msg: discord.Message):
            return (
                msg.author.id == self.owner_id
                and msg.channel == interaction.channel
                and not msg.author.bot
            )

        try:
            msg: discord.Message = await self.bot.wait_for(
                "message", timeout=120.0, check=check
            )
        except asyncio.TimeoutError:
            await interaction.followup.send(
                "시간이 초과되었습니다. 다시 시도해 주세요.", ephemeral=True
            )
            return

        # 파싱 시도 (날짜, 카테고리, 금액[, 업체명])
        try:
            parts = [x.strip() for x in msg.content.split(",")]
            if len(parts) not in (3, 4):
                raise ValueError("형식은 3개 또는 4개 값이어야 합니다.")

            new_date, new_category, new_amount = parts[:3]
            if len(parts) == 4:
                new_store = parts[3]
            else:
                new_store = self.ocr_data.get("store", "-")

            if new_category not in BASE_CATEGORIES:
                raise ValueError("카테고리는 정해진 5가지 + 기타 중 하나여야 합니다.")

            cost_val = int(new_amount.replace(",", ""))

            self.ocr_data["date"] = new_date
            self.ocr_data["category"] = new_category
            self.ocr_data["cost"] = cost_val
            self.ocr_data["store"] = new_store

            save_receipt_row(self.ocr_data)

            await interaction.followup.send(
                "수정된 값으로 저장했어요!\n"
                f"- 날짜: {new_date}\n"
                f"- 카테고리: {new_category}\n"
                f"- 금액: {cost_val}\n"
                f"- 업체: {new_store}",
                ephemeral=True,
            )
            self.stop()
        except Exception as e:
            await interaction.followup.send(
                "형식이 잘못되었습니다. 예시처럼 입력해 주세요:\n"
                "`2025-12-10, 식비, 8300, 알촌`\n"
                f"(오류: {e})",
                ephemeral=True,
            )


# ---------------------------------------------------------
#  Donut 모델 로딩 (CPU)
# ---------------------------------------------------------
print("[ocr_model] device = cpu")
PROCESSOR, MODEL, DEVICE = load_ocr_model(device="cpu")
print("[ocr_model] Donut model loaded")


# ---------------------------------------------------------
#  Discord 이벤트: 이미지 수신 → OCR → 임베드 + 버튼
# ---------------------------------------------------------
@bot.event
async def on_ready():
    print(f"Discord 봇 로그인 완료: {bot.user} (id={bot.user.id})")


@bot.event
async def on_message(message: discord.Message):
    # 명령어 처리
    await bot.process_commands(message)

    # 자기 자신 / 다른 봇 무시
    if message.author.bot:
        return

    # 이미지 첨부 없으면 무시
    if not message.attachments:
        return

    attachment = message.attachments[0]

    # 이미지가 아니면 무시
    if attachment.content_type and "image" not in attachment.content_type:
        return

    # ===== 이미지 임시 저장 =====
    tmp_path = os.path.join(TMP_DIR, f"{uuid4().hex}_{attachment.filename}")
    await attachment.save(tmp_path)

    # ===== OCR 실행 =====
    try:
        raw_output, json_text, parsed = run_ocr(tmp_path, PROCESSOR, MODEL, DEVICE)
    except Exception as e:
        await message.channel.send("영수증을 처리하는 중 오류가 발생했습니다. 나중에 다시 시도해 주세요.")
        print("OCR Error:", e)
        if os.path.exists(tmp_path):
            os.remove(tmp_path)
        return
    finally:
        if os.path.exists(tmp_path):
            os.remove(tmp_path)

    # parsed 예시: {"date": "...", "store": "...", "total": "..."}
    date_str = (parsed.get("date") or "?").strip()
    store_name = (parsed.get("store") or "-").strip()
    amount = parsed.get("total") or "0"
    try:
        cost_int = int(str(amount).replace(",", "").split(".")[0])
    except Exception:
        cost_int = 0

    category = guess_category(store_name, raw_output or json_text or "")

    # ===== Embed 구성 =====
    embed = discord.Embed(
        title="영수증 자동 추정 결과",
        color=0x2ecc71,
    )
    embed.add_field(name="카테고리(추정)", value=category or "?", inline=False)
    embed.add_field(name="금액(추정)", value=f"{cost_int}", inline=True)
    embed.add_field(name="일시(추정)", value=date_str or "?", inline=True)
    embed.add_field(name="업체", value=store_name or "-", inline=False)
    embed.add_field(name="원본", value=f"[파일보기]({attachment.url})", inline=False)

    # ledger에 저장할 딕셔너리 (아직은 '추정' 상태)
    ocr_data = {
        "date": date_str,
        "store": store_name,
        "category": category,
        "cost": cost_int,
        "json_text": json_text,
    }

    view = ReceiptView(bot, ocr_data, message.author.id)
    await message.channel.send(embed=embed, view=view)


# ---------------------------------------------------------
#  가계부 요약 명령들
#   !가계부 [YYYY-MM]  -> 해당 월
#   !오늘              -> 오늘 하루
#   !이번주            -> 이번 주(월~일)
# ---------------------------------------------------------
@bot.command(name="가계부", aliases=["ledger", "month"])
async def monthly_ledger(ctx, year_month: str = None):
    """
    사용법:
      !가계부          -> 이번 달 요약
      !가계부 2025-11 -> 2025-11 월 요약
    """
    rows = load_ledger_rows()
    if not rows:
        await ctx.send("아직 저장된 지출 내역이 없어요.")
        return

    if year_month is None:
        today = date.today()
        year_month = f"{today.year:04d}-{today.month:02d}"

    month_rows = [r for r in rows if r["date"].startswith(year_month)]
    await send_summary(ctx, month_rows, f"{year_month} 월 가계부 요약")


@bot.command(name="오늘", aliases=["today"])
async def today_ledger(ctx):
    """오늘 하루 지출 요약"""
    rows = load_ledger_rows()
    if not rows:
        await ctx.send("아직 저장된 지출 내역이 없어요.")
        return

    today = date.today().strftime("%Y-%m-%d")
    today_rows = [r for r in rows if r["date"] == today]
    await send_summary(ctx, today_rows, f"{today} 하루 가계부")


@bot.command(name="이번주", aliases=["week"])
async def week_ledger(ctx):
    """이번 주(월~일) 지출 요약"""
    rows = load_ledger_rows()
    if not rows:
        await ctx.send("아직 저장된 지출 내역이 없어요.")
        return

    today = date.today()
    start = today - timedelta(days=today.weekday())  # 이번 주 월요일
    end = start + timedelta(days=6)                  # 이번 주 일요일

    def parse_d(s: str):
        try:
            return datetime.strptime(s[:10], "%Y-%m-%d").date()
        except Exception:
            return None

    week_rows = []
    for r in rows:
        d = parse_d(r["date"])
        if d and start <= d <= end:
            week_rows.append(r)

    title = f"{start.strftime('%Y-%m-%d')} ~ {end.strftime('%Y-%m-%d')} 주간 가계부"
    await send_summary(ctx, week_rows, title)


# ---------------------------------------------------------
#  봇 실행
# ---------------------------------------------------------
if __name__ == "__main__":
    bot.run(DISCORD_TOKEN)
