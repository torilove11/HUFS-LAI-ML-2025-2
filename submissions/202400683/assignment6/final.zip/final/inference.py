import torch
import numpy as np
import pandas as pd

from model import BeatSaberMLP

# GPU 사용 가능 여부 확인
if torch.cuda.is_available():
    print("CUDA is available! Success!")
    print(f"Device Name: {torch.cuda.get_device_name(0)}")
else:
    print("CUDA is NOT available. Check installation.")
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

model = BeatSaberMLP()
# 저장된 가중치 파일 불러오기
state_dict = torch.load('beatsaber_model_weights.pth', map_location=device)
# 3. 모델에 가중치 입히기
model.load_state_dict(state_dict)
# 4. 모델을 해당 장치(GPU/CPU)로 이동
model.to(device)
print("모델 가중치 로드 완료!")

def prepare_data(X_df, device):
    # 1. X 데이터: DataFrame -> Numpy -> FloatTensor -> GPU로 이동
    X_tensor = torch.tensor(X_df.values, dtype=torch.float32).to(device)
    return X_tensor

def get_infer(X):
    X_for_df = {k: [v] for k, v in X.items()}
    X_df = pd.DataFrame(X_for_df)
    X_gpu = prepare_data(X_df, device)
    model.eval()
    with torch.no_grad():
        output = model(X_gpu)
        prob = torch.softmax(output, dim=1)
        pred = torch.argmax(prob)
        extracted_pred = pred.cpu().item()
        return extracted_pred

