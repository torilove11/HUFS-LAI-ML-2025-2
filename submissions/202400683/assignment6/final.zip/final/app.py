import load_info
import load_level
import inference

all_levels = load_info.load_songs()
all_levels.sort(key=lambda x: x['lvlNo'])

int_to_diff = {0: 'Easy', 1: 'Normal', 2: 'Hard', 3: 'Expert', 4: 'ExpertPlus'}
print("비트세이버 난이도 분석기")
while True:
    raw_com = input("명령어: ")
    if raw_com:
        commands = list(raw_com.split())
    else:
        commands = "none"
    if commands[0] in ['exit', 'quit', 'q', 'Q']:
        print("종료")
        break
    elif (commands[0] == 'list'):
        print("===== 레벨 리스트 =====")
        print("번호 이름(난이도)")
        for level in all_levels:
            print(f"{level['lvlNo']:4d} {level['songName']}({int_to_diff[level['diff']]})")
    elif (commands[0]) == 'diff':
        if commands[1].isdigit():
            print("난이도 재예측 결과")
            lvlNo = int(commands[1])
            X, Y = load_level.get_data(all_levels[lvlNo])
            pred = inference.get_infer(X)
            print(f"표기 난이도: {int_to_diff[Y]}")
            print(f"재예측 난이도: {int_to_diff[pred]}")
        else:
            print("유효하지 않은 형식")
    else:
        print("유효하지 않은 명령어 입니다.")



