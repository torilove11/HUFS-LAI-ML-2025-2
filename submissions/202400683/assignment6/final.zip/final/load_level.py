import os
import json
import pandas as pd

def get_data(level : dict):
    try:
        path = level['infoPath'][:-8] + level['fileName']
        with open(path, "r", encoding="utf-8") as f:
            loaded_dict = json.load(f)
            loaded_dict.update({'lvlNo' : level['lvlNo']})
        if not ('_version' in loaded_dict or 'version' in loaded_dict):
            loaded_dict.update({'_version' : '2.0.0'})

        notes = []
        if '_version' in loaded_dict: # 2.0.0 ~ 2.6.0
            for note in loaded_dict['_notes']:
                notes.append({'b' : note['_time'], # 비트
                            'x' : note['_lineIndex'], # x축 위치 (0, 1, 2, 3), 0부터 왼쪽
                            'y' : note['_lineLayer'], # y축 위치 (0, 1, 2), 0부터 아래쪽
                            't' : note['_type'], # type (0: 왼손, 1: 오른손, 3: 폭탄)
                            'd' : note['_cutDirection'], # 베는 방향
                            'abs' : note['_time'] / level['bpm'] * 60}) # 곡 시작 후 노트 절대 시간 (초)
        elif 'version' in loaded_dict: # 3.0.0 ~
            if loaded_dict['version'] == '4.0.0': # 4.0.0: 노트의 조회가 템플릿 방식으로 변경됨.
                note_temp = []
                for nt in loaded_dict["colorNotesData"]: # 일반 노트 템플릿 로드
                    note_temp.append({'x' : nt.get('x', 0), # 해당 키가 없는 경우 기본값인 0으로 할당
                                    'y' : nt.get('y', 0),
                                    't' : nt.get('c', 0),
                                    'd' : nt.get('d', 8)}) # 방향 정보가 없는 경우 무방향인 8번 할당
                for note in loaded_dict["colorNotes"]: # 일반 노트 추가
                    notes.append({'b' : note['b'],
                                'x' : note_temp[note.get('i', 0)]['x'], # 템플릿 정보가 없는 경우 첫번째 템플릿 할당
                                'y' : note_temp[note.get('i', 0)]['y'],
                                't' : note_temp[note.get('i', 0)]['t'],
                                'd' : note_temp[note.get('i', 0)]['d'],
                                'abs' : note['b'] / level['bpm'] * 60})
                bomb_temp = []
                for nt in loaded_dict["bombNotesData"]: # 폭탄 노트 템플릿 로드
                    bomb_temp.append({'x' : nt.get('x', 0),
                                    'y' : nt.get('y', 0),
                                    't' : 3,
                                    'd' : 0})
                for note in loaded_dict["bombNotes"]: # 폭탄 노트 리스트 뒤에 추가
                    notes.append({'b' : note['b'],
                                'x' : note_temp[note.get('i', 0)]['x'],
                                'y' : note_temp[note.get('i', 0)]['y'],
                                't' : note_temp[note.get('i', 0)]['t'],
                                'd' : note_temp[note.get('i', 0)]['d'],
                                'abs' : note['b'] / level['bpm'] * 60})
                notes.sort(key=lambda x: x['b']) # 폭탄 노트까지 더해진 리스트를 비트 즉, 등장 순서에 맞춰서 정렬 (일반 노트와 폭탄 노트가 같은 비트에 위치할 경우 일반 노트가 더 빠른 순서)

            else: # 3.x.x: 폭탄 노트 (치면 안되는 노트)와 일반노트가 서로 다른 리스트로 구분됨.
                for note in loaded_dict["colorNotes"]: # 일반 노트 추가
                    notes.append({'b' : note['b'],
                                'x' : note.get('x', 0),
                                'y' : note.get('y', 0),
                                't' : note.get('c', 0),
                                'd' : note.get('c', 8),
                                'abs' : note['b'] / level['bpm'] * 60})
                for note in loaded_dict['bombNotes']: # 리스트 끝에 폭탄 노트를 추가
                    notes.append({'b' : note['b'],
                                'x' : note.get('x', 0),
                                'y' : note.get('y', 0),
                                't' : 3,
                                'd' : 0,
                                'abs' : note['b'] / level['bpm'] * 60})
                notes.sort(key=lambda x: x['b'])

        notes_list = notes
        duration = notes[-1]['abs'] + 1 if len(notes) else 1
        grid_counts = [[0 for _ in range(3)] for _ in range(4)]

        for note in notes_list:
            if note['x'] >= 0 and note['x'] <= 3 and note['y'] >= 0 and note['y'] <= 2:
                x = note['x']
                y = note['y']
                grid_counts[x][y] += 1
        
        nps_vector = {}
        for x in range(4):
            for y in range(3):
                col_name = f'NPS_{x}_{y}'
                count = grid_counts[x][y]
                nps_vector[col_name] = count / duration
        
        global_features = {}
        global_features['bpm'] = (level['bpm'] - 80) / (300 - 80)
        global_features['njs'] = (level['njs'] - 0) / (999 - 0)
        X = nps_vector | global_features
        Y = level['diff']
        return X, Y

    except FileNotFoundError:
        print(f"오류: 파일 경로를 확인해주세요: {level['infoPath']}")
        return None
    except json.JSONDecodeError as e:
        print(f"오류: JSON 구문 분석 중 오류 발생. 파일 내용이 올바른 JSON 형식이 아닐 수 있습니다. ({e})")
        return None
    
    