import os
import json

def load_songs(levels_path : str = "./CustomLevels/") -> list:
# 지정된 경로에 있는 폴더명(곡)을 리스트로 반환
    all_songs = os.listdir(levels_path)

    # 각 폴더에 있는 info.dat 파일들을 load
    all_info = []
    for i, song in enumerate(all_songs):
        try:
            info_path = levels_path+song+"/info.dat"
            with open(info_path, "r", encoding="utf-8") as f:
                loaded_dict = json.load(f)
                loaded_dict.update({'info_path':info_path, 'song_no':i}) # info.dat 파일의 경로와 로드된 순서대로 번호 컬럼을 추가.
                all_info.append(loaded_dict)
        except FileNotFoundError:
            print(f"오류: 파일 경로를 확인해주세요: {info_path}")
        except json.JSONDecodeError as e:
            print(f"오류: JSON 구문 분석 중 오류 발생. 파일 내용이 올바른 JSON 형식이 아닐 수 있습니다. ({e})")

    diff_to_int = {'Easy' : 0, 'Normal' : 1, 'Hard' : 2, 'Expert' : 3, 'ExpertPlus' : 4}
    all_levels = []
    levelNo = 0
    for info in all_info:
        noStandard = True
        if '_version' in info: # 버전: 2.0.0 or 2.1.0 필요한 데이터 구조는 동일
            for mode in info['_difficultyBeatmapSets']:
                if mode['_beatmapCharacteristicName'] == "Standard": # 데이터의 편향 및 이상치 방지를 위해 Stardard 형식만 사용.
                    noStandard = False
                    for level in mode['_difficultyBeatmaps']:
                        all_levels.append({'ver' : info['_version'],
                                        'songName' : info['_songName'],
                                        'bpm' : info['_beatsPerMinute'],
                                        'diff' : diff_to_int[level['_difficulty']],
                                        'fileName' : level['_beatmapFilename'],
                                        'njs' : level["_noteJumpMovementSpeed"],
                                        'songNo' : info['song_no'],
                                        'infoPath' : info['info_path'],
                                        'lvlNo' : levelNo})
                        levelNo += 1
                        
        elif 'version' in info: # 버전 4.0.0 or 4.0.1 필요한 데이터 구조는 동일
            for level in info['difficultyBeatmaps']:
                if level['characteristic'] == "Standard":
                    noStandard = False
                    all_levels.append({'ver' : info['version'],
                                        'songName' : info['song']['title'],
                                        'bpm' : info['audio']['bpm'],
                                        'diff' : diff_to_int[level['difficulty']],
                                        'fileName' : level['beatmapDataFilename'],
                                        'njs' : level["noteJumpMovementSpeed"],
                                        'songNo' : info['song_no'],
                                        'infoPath' : info['info_path'],
                                        'lvlNo' : levelNo})
                    levelNo += 1
        
        else:
            print('Invalid song info')
            continue

        if noStandard:
            print("This song has no Standard beatmap. It will be excluded!")
            print(f"Excluded song: {info['song_no']} : {info['_songName']}")

    return all_levels


