import streamlit as st
import pandas as pd
import joblib
import os

# ========================================================
# 1. 기본 설정 및 파일 로드
# ========================================================

st.set_page_config(
    page_title="F1 경기 추천기",
    page_icon="🏎️",
    layout="centered"
)

# 파일 경로 설정
possible_paths = ['.', './data']
MODEL_FILE = 'f1_excitement_model.pkl'
SCALER_FILE = 'scaler_features.pkl'
DATA_FILE = 'f1_race_data_2021_2025_merged.csv'

def find_file(filename):
    for path in possible_paths:
        full_path = os.path.join(path, filename)
        if os.path.exists(full_path):
            return full_path
    return None

model_path = find_file(MODEL_FILE)
scaler_path = find_file(SCALER_FILE)
data_path = find_file(DATA_FILE)

# 캐싱
@st.cache_resource
def load_model_and_scaler(m_path, s_path):
    if m_path and s_path:
        try:
            m = joblib.load(m_path)
            s = joblib.load(s_path)
            return m, s
        except Exception as e:
            st.error(f"모델 로드 중 에러 발생: {e}")
            return None, None
    return None, None

@st.cache_data
def load_data(d_path):
    if d_path:
        try:
            return pd.read_csv(d_path)
        except Exception as e:
            st.error(f"데이터 로드 중 에러 발생: {e}")
            return None
    return None

# 실제 로딩 수행
model, scaler = load_model_and_scaler(model_path, scaler_path)
df = load_data(data_path)

# ========================================================
# 2. UI 구성 (Title & Intro)
# ========================================================
st.title("🏎️ F1 경기 추천기")
st.markdown("""
이 서비스는 **Random Forest 모델**을 활용하여 F1 경기의 재미(평점)를 예측합니다.
- **과거 데이터 불러오기**: 실제 경기를 복기하며 모델을 검증해보세요.
- **시뮬레이션**: *"만약 여기서 사고가 더 났다면?"* 과 같이 가상의 시나리오를 실험해보세요.
""")
st.divider()

# 필수 파일이 없는 경우 경고 메시지 출력 후 중단
if model is None or scaler is None:
    st.error("❌ 중요 파일이 누락되었습니다.")
    st.warning(f"다음 파일들이 '{os.getcwd()}' 또는 'data/' 폴더에 있는지 확인해주세요.")
    st.code(f"- {MODEL_FILE}\n- {SCALER_FILE}", language="bash")
    st.stop()

# ========================================================
# 3. 사이드바: 과거 경기 프리셋 (Preset Selection)
# ========================================================
st.sidebar.header("📂 과거 경기 데이터 불러오기")
st.sidebar.info("실제 있었던 경기를 선택하면 당시 기록이 자동으로 입력됩니다.")

# 기본값 초기화 (평범한 경기 기준)
default_values = {
    'chaos': 5, 'lead': 1, 'gap': 5.0, 
    'pos': 30, 'sc': 1, 'red': 0
}

# CSV 데이터가 있다면 드롭다운 생성
if df is not None:
    # 가독성 좋은 라벨 생성 (예: 2021 Rd.1 - Bahrain GP)
    df['Label'] = df['Year'].astype(str) + " Rd." + df['Round'].astype(str) + " - " + df['GrandPrix']
    
    # 최신순으로 정렬 (역순)
    race_options = ["직접 입력 (Custom Simulation)"] + df['Label'].tolist()[::-1]
    
    selected_race = st.sidebar.selectbox("경기 선택:", race_options)

    # 사용자가 특정 경기를 선택했을 때 -> 기본값을 해당 경기 데이터로 덮어쓰기
    if selected_race != "직접 입력 (Custom Simulation)":
        row = df[df['Label'] == selected_race].iloc[0]
        
        default_values['chaos'] = int(row['Chaos_Score'])
        default_values['lead'] = int(row['Lead_Changes'])
        default_values['gap'] = float(row['Gap_Std_Dev'])
        default_values['pos'] = int(row['Position_Gains_Total'])
        default_values['sc'] = int(row['SC_Count'])
        default_values['red'] = int(row['Red_Flag_Count'])
        
        st.sidebar.success(f"✅ 데이터 로드 완료!\n(선택된 경기: {selected_race})")
else:
    st.sidebar.warning("⚠️ 데이터 파일(csv)을 찾을 수 없어 프리셋 기능을 사용할 수 없습니다.")

# ========================================================
# 4. 메인 입력 화면 (Inputs)
# ========================================================
st.subheader("📊 경기 데이터 설정 (Simulation)")
st.caption("""
- 슬라이더를 움직여 가상의 상황(What-if)을 만들어보세요.
- SC나 레드 플래그를 조절하면 **Chaos Score**가 자동으로 계산됩니다.
""")

col1, col2 = st.columns(2)

with col1:
    st.markdown("#### 💥 사고 및 변수")
    
    # 1. SC와 Red Flag 입력 (원인 변수)
    sc_count = st.number_input("🚑 세이프티 카 (SC) 횟수 [x3점]", 0, 10, default_values['sc'])
    red_flag = st.number_input("🚩 레드 플래그 (Red Flag) 횟수 [x5점]", 0, 5, default_values['red'])
    
    # 2. 나머지 요소(VSC 등)는 슬라이더로 처리
    # (Preset에서 불러올 때: 전체 Chaos - (SC*3 + Red*5) = 나머지 Chaos)
    calculated_base_chaos = (default_values['sc'] * 3) + (default_values['red'] * 5)
    default_vsc = max(0, default_values['chaos'] - calculated_base_chaos)
    
    # [수정됨] st.slider -> st.number_input
    vsc_count = st.number_input("⚠️ 버추얼 세이프티 카 (VSC) 횟수 [x1점]", 0, 20, int(default_vsc))

    # 3. [핵심] Chaos Score 자동 계산 (공식 적용)
    chaos_score = (sc_count * 3) + (red_flag * 5) + vsc_count
    
    # 계산된 점수 실시간 표시
    st.info(f"계산된 총 Chaos Score: **{chaos_score}점**")

with col2:
    st.markdown("#### ⚔️ 레이싱 액션")
    position_gains = st.slider("순위 변동 총합 (Position Gains)", 0, 100, default_values['pos'], help="출발 순위 대비 도착 순위가 바뀐 횟수의 총합")
    lead_changes = st.number_input("선두 교체 횟수", 0, 20, default_values['lead'])
    gap_std = st.slider("1-2위 격차 표준편차", 0.0, 20.0, default_values['gap'], help="작을수록 1등과 2등이 경기 내내 붙어 있었다는 뜻")

# ========================================================
# 5. 예측 및 결과 가이드 (Prediction & Guide)
# ========================================================
st.divider()

if st.button("AI 평점 예측 시작", type="primary", use_container_width=True):
    
    # 1. 입력 데이터프레임 생성
    input_df = pd.DataFrame({
        'Chaos_Score': [chaos_score],
        'Lead_Changes': [lead_changes],
        'Gap_Std_Dev': [gap_std],
        'Position_Gains_Total': [position_gains],
    })
    
    # 2. 스케일링 적용
    try:
        input_scaled = scaler.transform(input_df)
    except Exception as e:
        st.error(f"스케일링 중 오류 발생: {e}")
        st.stop()
    
    # 3. 예측 수행
    try:
        raw_prediction = model.predict(input_scaled)[0]
        
        prediction = raw_prediction * 10
        
        # 0~10 사이로 자르기
        if prediction > 10: prediction = 10.0
        if prediction < 0: prediction = 0.0
    except Exception as e:
        st.error(f"예측 중 오류 발생: {e}")
        st.stop()
    
    # 4. 결과 출력
    st.subheader("AI의 시청 추천 (Recommendation)")
    
    c1, c2 = st.columns([1, 2])
    
    with c1:
        # 점수 표시
        st.metric(label="🏆 예상 평점", value=f"{prediction:.2f} / 10")
    
    with c2:
        # 점수 구간별 행동 가이드
        if prediction >= 7.0:
            st.success("🌟 **[전체 다시보기] 추천**")
            st.markdown("""
            - 전체 경기를 봐도 시간이 아깝지 않은 경기입니다.
            """)
            
        elif prediction >= 5.5:
            st.info("⏩ **[하이라이트] 추천**")
            st.markdown("""
            - 전체를 다 보기엔 루즈한 구간이 있습니다.
            - F1 유튜브에 업로드되는 **하이라이트**(15분)를 먼저 보고, 재밌는 구간만 찾아보세요.
            """)
            
        else:
            st.warning("⚡ **[요약본] or [결과 확인]만 하세요**")
            st.markdown("""
            - 2시간을 투자하기엔 다소 지루한 경기입니다.
            - 5분 요약 영상을 보거나, 결과만 확인해도 별 상관이 없습니다.
            """)

    # 디버깅용: 실제 모델에 들어가는 값 확인
    with st.expander("🔍 AI 입력 데이터 확인 (Debug Info)"):
        st.write("원본 입력값:", input_df)
        st.write("스케일링된 값:", input_scaled)

st.caption("""
**Credit**: 본 과제는 Gemini의 도움을 받아 수행하였습니다.
""")