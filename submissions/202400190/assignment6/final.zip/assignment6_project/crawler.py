import time
import re
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager
from bs4 import BeautifulSoup


class NaverReviewCrawler:
    def __init__(self):
        options = Options()
        options.add_argument("--headless")  # 브라우저 창을 보고 싶을 시 주석 해제

        # 봇 탐지 방지용 User-Agent 설정
        options.add_argument(
            "user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        )
        options.add_argument("--start-maximized")
        options.add_experimental_option("excludeSwitches", ["enable-automation"])
        options.add_experimental_option("useAutomationExtension", False)

        self.driver = webdriver.Chrome(
            service=Service(ChromeDriverManager().install()), options=options
        )

    def get_reviews(self, url, max_reviews=50):
        print(f"[크롤러] 접속 중: {url}")
        self.driver.get(url)
        time.sleep(3)

        # 식당 이름 가져오기 (네이버 플레이스 모바일 제목 클래스 찾기)
        try:
            # 보통 '.GHAhO' 클래스가 제목입니다. (변경될 수 있어 예외처리)
            restaurant_name = self.driver.find_element(By.CSS_SELECTOR, ".GHAhO").text
        except:
            try:
                # 다른 클래스 이름 시도
                restaurant_name = self.driver.find_element(
                    By.CSS_SELECTOR, ".Fc1rA"
                ).text
            except:
                restaurant_name = "식당(이름 못 찾음)"

        print(f"   -> 식당 이름: {restaurant_name}")

        # 1. 탭 & 정렬 클릭 (리뷰 탭 -> 최신순)
        try:
            # '리뷰' 탭 클릭
            self.driver.find_element(By.XPATH, "//*[contains(text(), '리뷰')]").click()
            time.sleep(2)
            # '최신순' 클릭
            self.driver.find_element(
                By.XPATH, "//*[contains(text(), '최신순')]"
            ).click()
            time.sleep(2)
        except:
            pass

        print(f"⬇️ [크롤러] 목표 {max_reviews}개를 채울 때까지 수집합니다...")

        reviews = []

        # 제외할 키워드 목록 (사용자 설정 유지)
        skip_keywords = [
            "선택한 인원",
            "이 키워드를",
            "좋아요",
            "방문자 리뷰",
            "영수증",
            "인증",
            "방문일",
            "안내",
            "리뷰 쓰기",
            "공유",
            "업체",
            "답글",
            "닫기",
            "새로고침",
            "지도",
            "복사",
            "팔로워",
            "팔로우",
            "다녀오셨나요",
            "펼쳐보기",
            "반응을 남겨",
            "톡톡",
            "테마",
            "이용약관",
            "운영정책",
            "신고센터",
            "고객센터",
            "사진·영상",
            "동영상",
            "시스템",
            "작동중",
            "대기 시간",
        ]

        last_height = self.driver.execute_script("return document.body.scrollHeight")
        same_height_count = 0
        scroll_cnt = 0

        # 목표 개수가 찰 때까지 반복 (While Loop)
        while len(reviews) < max_reviews:
            # 1. 스크롤 내리기
            self.driver.execute_script(
                "window.scrollTo(0, document.body.scrollHeight);"
            )
            time.sleep(0.6)
            scroll_cnt += 1

            # 2. '더보기' 버튼 클릭
            if scroll_cnt % 3 == 0:
                try:
                    self.driver.find_element(By.CSS_SELECTOR, "a.fvwqf").click()
                except:
                    pass

            # 3. 현재 페이지 파싱 (실시간 수집)
            html = self.driver.page_source
            soup = BeautifulSoup(html, "html.parser")
            all_tags = soup.find_all(["span", "div", "a"])

            # 이번 턴에 수집한 것들을 임시 리스트에 담지 않고 바로 reviews에 조건 체크 후 추가
            for tag in all_tags:
                text = tag.get_text(strip=True)

                # [1차 필터] 글자 수 제한
                if len(text) < 15:
                    continue
                if len(text) > 1000:
                    continue

                # [2차 필터] 프로필 정보
                if re.search(r"리뷰\s*[\d,]+.*사진", text):
                    continue

                # [3차 필터] 방문 정보
                if "이용대기 시간" in text or "바로 입장" in text or "방문포장" in text:
                    continue

                # [4차 필터] 금지어
                is_clean = True
                for skip in skip_keywords:
                    if skip in text:
                        is_clean = False
                        break

                # [5차 필터] 한글 비중
                if is_clean:
                    korean_chars = len(re.findall(r"[가-힣]", text))
                    if korean_chars < 5:
                        is_clean = False

                # [6차 필터] 메뉴판 제거
                if re.search(r"^메뉴[가-힣]+[0-9]+", text):
                    continue
                if "메뉴" in text and len(re.findall(r"[0-9]+", text)) > 3:
                    continue

                # [7차 필터] 모든 년도 표기 제거 (정규표현식)
                if re.search(r"\d{4}년", text):
                    continue

                # [저장]
                if is_clean:
                    if text not in reviews:
                        if not any(text in r for r in reviews) and not any(
                            r in text for r in reviews
                        ):
                            reviews.append(text)

                # 목표 달성 시 루프 탈출
                if len(reviews) >= max_reviews:
                    break

            # [종료 조건] 스크롤을 내려도 더 이상 내용이 없으면 종료
            new_height = self.driver.execute_script("return document.body.scrollHeight")
            if new_height == last_height:
                same_height_count += 1
                if same_height_count >= 10:  # 10번 연속 변화 없으면 끝난 걸로 간주
                    print("⚠️ 더 이상 로딩될 리뷰가 없습니다.")
                    break
            else:
                last_height = new_height
                same_height_count = 0

            # 안전장치: 너무 오래 걸리면 강제 종료 (200번 스크롤)
            if scroll_cnt > 200:
                print("⚠️ 너무 오래 걸려서 중단합니다.")
                break

        # 혹시라도 0개면 비상용 데이터 반환
        if len(reviews) == 0:
            print("⚠️ [결과 없음] 비상용 데이터를 반환합니다.")
            reviews = [
                "비상용: 음식이 맛있고 분위기가 좋아요.",
                "비상용: 재방문 의사 있습니다.",
            ]

        print(f"[크롤러] 최종 수집 완료: {len(reviews)}개")
        self.driver.quit()
        return restaurant_name, reviews


if __name__ == "__main__":
    # 테스트용 URL
    url = "https://m.place.naver.com/restaurant/20838941/review/visitor"
    crawler = NaverReviewCrawler()
    result = crawler.get_reviews(url, 50)

    print("\n--- 결과 ---")
    for i, r in enumerate(result):
        print(f"[{i+1}] {r}")
