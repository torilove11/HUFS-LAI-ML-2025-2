import streamlit as st
import pandas as pd
import torch
import torch.nn.functional as F
from transformers import AutoTokenizer, AutoModelForSequenceClassification
import google.generativeai as genai
import os
import zipfile
import gdown
import shutil
import re
import json  # JSON 처리(속도 향상)
from crawler import NaverReviewCrawler
import altair as alt


# --- 전처리 함수 (특수문자 및 이모티콘 제거) ---
def clean_text(text):
    """모델 입력 전 텍스트에서 이모티콘, 특수문자 등을 제거합니다."""
    # 한글, 영어, 숫자, 공백, 마침표(.)를 제외한 모든 문자를 제거합니다.
    text = re.sub(r"[^가-힣a-zA-Z0-9\s\.]", "", text)
    return text.strip()


# --- LLM 통합 Batch 처리 함수 (키워드 추출, 문장 생성, 유효성 검증) ---
def process_reviews_batch(reviews, current_api_key):
    """모든 리뷰를 LLM에 한 번에 보내 유효성 검증 및 키워드 문장을 JSON 형식으로 반환합니다."""
    if not current_api_key:
        return []

    try:
        genai.configure(api_key=current_api_key)
        model = genai.GenerativeModel("gemini-2.5-flash")

        # LLM 프롬프트: 리뷰 목록과 인덱스를 함께 전달
        review_list_str = "\n".join([f"[{i}]: {r}" for i, r in enumerate(reviews)])

        prompt = f"""
        다음은 네이버 리뷰 목록입니다. 각 항목에 대해 아래 JSON Schema에 맞춰 응답하세요.
        1. 'is_valid'는 텍스트가 순수 리뷰 본문(경험 서술)일 경우 YES, 태그나 시스템 메시지일 경우 NO로 판단하세요. (예: 지인·동료, 친구, 형제자매 같은 태그는 NO)
        2. 'summary_sentence'는 'is_valid'가 YES일 경우에만 핵심 내용을 담은 **하나의 간결하고 자연스러운 문장**으로 요약하세요. 30자를 넘기지 마세요.

        [리뷰 목록]
        {review_list_str}
        """

        response = model.generate_content(
            prompt,
            generation_config={
                "response_mime_type": "application/json",
                "response_schema": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "review_index": {"type": "integer"},
                            "is_valid": {"type": "string", "enum": ["YES", "NO"]},
                            "summary_sentence": {"type": "string"},  # 키워드 기반 문장
                        },
                        "required": ["review_index", "is_valid", "summary_sentence"],
                    },
                },
            },
        )
        return json.loads(response.text)

    except Exception as e:
        # JSON 파싱 오류 등 발생 시
        st.error(f"LLM Batch 처리 중 JSON 오류 발생: {str(e)}")
        return []


# --- LLM 요약 함수 (긍정/부정 탭용) ---
def summarize_reviews(reviews, sentiment_type):
    if not api_key:
        return "Gemini API Key가 입력되지 않아 요약할 수 없습니다."

    try:
        genai.configure(api_key=api_key)
        gemini_model = genai.GenerativeModel("gemini-2.5-flash")
        text_chunk = "\n".join(reviews[:30])

        prompt = f"""
        다음은 식당에 대한 '{sentiment_type}' 리뷰들입니다.
        이 리뷰들을 분석하여 공통적인 핵심 내용 3가지를 추출하고, 아래 형식에 맞춰 작성하세요.

        [출력 형식]
        다음은 {sentiment_type} 리뷰에서 주로 언급된 내용 3가지입니다.

        1. (핵심 내용 1) ~습니다.
        2. (핵심 내용 2) ~습니다.
        3. (핵심 내용 3) ~습니다.

        [제약 사항]
        - 반드시 위의 출력 형식을 그대로 따르세요.
        - 각 문장의 어미는 반드시 '~습니다'체(하십시오체)로 끝나야 합니다. (예: 맛있습니다, 친절합니다)
        - 서두나 맺음말 없이 위 형식의 텍스트만 출력하세요.

        [리뷰 데이터]
        {text_chunk}
        """

        response = gemini_model.generate_content(prompt)
        return response.text
    except Exception as e:
        return f"요약 중 오류 발생: {str(e)}"


# --- 페이지 설정 ---
st.set_page_config(page_title="맛집 리뷰 AI 분석기", page_icon="🍽️", layout="wide")
st.title("🍽️ 맛집 리뷰 AI 분석 & 요약 서비스")
st.markdown("Assignment 6: ML Classification (PyTorch) + LLM Summarization")
st.divider()

# --- 사이드바 설정 ---
st.sidebar.header("⚙️ 설정")

# [API Key 설정] (코드에 직접 삽입)
GEMINI_API_KEY = "AIzaSyDz88Svy1Z44zK5A12J-HuO9iwDo2DSsAE"

if GEMINI_API_KEY.startswith("AIzaSy"):
    st.sidebar.success("✅ API Key 설정됨")
    api_key = GEMINI_API_KEY
else:
    st.sidebar.error("API Key를 코드를 확인하세요.")
    api_key = None

url = st.sidebar.text_input(
    "네이버 플레이스 URL",
    "https://m.place.naver.com/restaurant/256285487/review/visitor",
)
target_count = st.sidebar.slider("수집할 리뷰 수", 10, 100, 30)
run_btn = st.sidebar.button("분석 시작", type="primary")


# --- 모델 다운로드 및 로드 함수 ---
@st.cache_resource
def load_model():
    model_dir = "./assignment5_final_model"

    if not os.path.exists(model_dir):
        with st.spinner("모델 파일이 없어 다운로드 중입니다..."):
            file_id = "1iwRFkAnueiGc9SPCzylBbPavJZ163fSz"
            url = f"https://drive.google.com/uc?id={file_id}"
            output = "assignment5_final_model.zip"

            gdown.download(url, output, quiet=False)

            with zipfile.ZipFile(output, "r") as zip_ref:
                zip_ref.extractall(model_dir)

            inner_files = os.listdir(model_dir)
            if len(inner_files) == 1 and inner_files[0] == "assignment5_final_model":
                nested_folder = os.path.join(model_dir, "assignment5_final_model")
                for file_name in os.listdir(nested_folder):
                    shutil.move(os.path.join(nested_folder, file_name), model_dir)
                os.rmdir(nested_folder)

            if os.path.exists(output):
                os.remove(output)

            st.success("모델 다운로드 및 설치 완료!")

    try:
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        tokenizer = AutoTokenizer.from_pretrained(model_dir)
        model = AutoModelForSequenceClassification.from_pretrained(model_dir)
        model.to(device)
        model.eval()
        return model, tokenizer, device
    except Exception as e:
        st.error(f"모델 로드 중 오류 발생: {e}")
        return None, None, None


model, tokenizer, device = load_model()

if model is None:
    st.stop()


# --- 추론 함수 ---
def predict_sentiment(text, model, tokenizer, device):
    inputs = tokenizer(
        text, return_tensors="pt", max_length=128, truncation=True, padding="max_length"
    )

    input_ids = inputs["input_ids"].to(device)
    attention_mask = inputs["attention_mask"].to(device)

    with torch.no_grad():
        outputs = model(input_ids, attention_mask=attention_mask)
        logits = outputs.logits

    probs = F.softmax(logits, dim=1).cpu().numpy()[0]
    pred_label = probs.argmax()
    confidence = probs[pred_label] * 100

    return pred_label, confidence


# --- 메인 실행 로직 ---
if run_btn and url:
    if not api_key:
        st.warning(
            "⚠️ Gemini API Key가 설정되지 않았습니다. LLM 요약/필터링 기능은 비활성화됩니다."
        )

    # --- 분석 시작 ---
    with st.status("🚀 데이터 수집 및 분석 중...", expanded=True) as status:
        st.write("네이버 리뷰 크롤링 중...")
        crawler = NaverReviewCrawler()
        restaurant_name, reviews = crawler.get_reviews(url, target_count)

        if not reviews:
            status.update(label="수집 실패", state="error")
            st.error("리뷰를 찾지 못했습니다.")
            st.stop()

        # 1. 전처리 적용
        st.write("리뷰 텍스트 전처리 중...")
        cleaned_reviews = [clean_text(r) for r in reviews]
        st.write(f"✅ '{restaurant_name}' 리뷰 {len(reviews)}개 수집 및 전처리 완료!")

        # 2. LLM Batch 호출 (유효성 검증 및 키워드 문장 생성)
        llm_results_map = {}
        if api_key:
            status.write("LLM 일괄 처리 중... (키워드 추출 및 태그 필터)")
            llm_results_list = process_reviews_batch(reviews, api_key)
            llm_results_map = {
                item.get("review_index"): item for item in llm_results_list
            }
        else:
            status.write("LLM 처리 건너뜀 (Key 없음)")

        # 3. 모델 예측 및 필터링
        results = []
        progress_bar = st.progress(0)

        for i, review in enumerate(cleaned_reviews):
            original_review = reviews[i]

            if not review or len(review) < 5:
                continue

            # LLM 결과 가져오기
            llm_data = llm_results_map.get(i)

            # [LLM 필터] 태그 데이터 제거
            if llm_data:
                is_valid = llm_data.get("is_valid", "NO").upper() == "YES"
                if not is_valid:
                    status.write(
                        f"  - 🤖 LLM이 태그로 판단하여 제거: {original_review[:20]}..."
                    )
                    continue  # 유효하지 않으면 다음 리뷰로

            # ML 예측 진행
            pred_label, confidence = predict_sentiment(review, model, tokenizer, device)

            # Raw_Conf: 모든 리뷰에 대해 '긍정일 확률'을 저장
            raw_conf = confidence if pred_label == 1 else (100 - confidence)

            # 키워드/문장 추출: LLM 결과에서 이미 추출된 문장을 사용
            if llm_data and "summary_sentence" in llm_data:
                summary = llm_data["summary_sentence"]
            else:
                # Key가 없거나, LLM 오류 발생 시 원본 리뷰 사용
                summary = original_review

            results.append(
                {
                    "Review": original_review,
                    "Keyword_Summary": summary,
                    "Sentiment_Code": pred_label,
                    "Sentiment": "긍정 😊" if pred_label == 1 else "부정 😡",
                    "Confidence": f"{confidence:.2f}%",
                    "Raw_Conf": raw_conf,
                }
            )
            progress_bar.progress((i + 1) / len(cleaned_reviews))

        df = pd.DataFrame(results)
        status.update(label="분석 완료!", state="complete", expanded=False)

    st.title(f"🏠 {restaurant_name}")
    col1, col2 = st.columns([1, 1])

    # [왼쪽] 차트 및 통계
    with col1:
        st.subheader("📊 감성 분석 결과")

        # 1. 확률 평균 계산
        avg_pos_prob = df["Raw_Conf"].mean()

        # 2. 개수 정보
        pos_count = len(df[df["Sentiment_Code"] == 1])
        total = len(df)

        # 3. 메트릭 표시 (확률 평균 사용)
        st.metric("평균 긍정 확률", f"{avg_pos_prob:.1f}%", delta=None)

        # 개수 정보는 캡션으로 따로 표시
        st.caption(f"총 {total}개 리뷰 중 긍정 {pos_count}개")

        # 차트용 데이터 준비
        chart_data = df["Sentiment"].value_counts().reset_index()
        chart_data.columns = ["Sentiment", "Count"]

        # Altair 차트 생성
        chart = (
            alt.Chart(chart_data)
            .mark_bar()
            .encode(
                x=alt.X("Sentiment", axis=alt.Axis(title="감성", labelAngle=0)),
                y=alt.Y("Count", axis=alt.Axis(title="리뷰 개수")),
                color=alt.Color(
                    "Sentiment",
                    scale=alt.Scale(
                        domain=["긍정 😊", "부정 😡"],
                        range=["#4CAF50", "#FF5252"],  # 초록, 빨강
                    ),
                    legend=None,
                ),
                tooltip=["Sentiment", "Count"],
            )
            .properties(height=300)  # 차트 높이 조절
        )

        st.altair_chart(chart, use_container_width=True)

        # 4. 최종 평가 (확률 평균 기반)
        if avg_pos_prob >= 80:
            st.info("🏆 강력 추천! 실패 없는 맛집")
        elif avg_pos_prob >= 50:
            st.warning("무난한 식당")
        else:
            st.error("🚨 주의! 부정적 여론 높은 식당")

    # [오른쪽] LLM 요약
    with col2:
        st.subheader("🤖 AI 핵심 요약")
        pos_reviews = df[df["Sentiment_Code"] == 1]["Review"].tolist()
        neg_reviews = df[df["Sentiment_Code"] == 0]["Review"].tolist()

        tab1, tab2 = st.tabs(["👍 긍정 요약", "👎 부정 요약"])

        with tab1:
            if pos_reviews:
                with st.spinner("요약 중..."):
                    st.info(summarize_reviews(pos_reviews, "긍정적"))
            else:
                st.write("리뷰 없음")

        with tab2:
            if neg_reviews:
                with st.spinner("요약 중..."):
                    st.error(summarize_reviews(neg_reviews, "부정적"))
            else:
                st.write("리뷰 없음")

    st.divider()
    st.subheader("📝 상세 분석 결과")

    # --- 정렬 로직 시작 (그룹별 정렬) ---

    # 1. 'Confidence_Value' 컬럼을 Raw_Conf 값으로 재사용
    # (Raw_Conf는 모든 리뷰에 대해 '긍정일 확률'을 나타냄)

    # 2. 긍정/부정 리뷰 그룹 분리
    df_pos = df[df["Sentiment_Code"] == 1].copy()
    df_neg = df[df["Sentiment_Code"] == 0].copy()

    # 3. 부정 리뷰 정렬 (우선 순위: 1순위)
    #   - 부정 확신도 높은 순: Raw_Conf(긍정 확률)이 낮은 순서로 정렬
    df_neg_sorted = df_neg.sort_values(
        by="Raw_Conf",
        ascending=True,  # Raw_Conf(긍정 확률)이 낮을수록 강한 부정 (오름차순)
    )

    # 4. 긍정 리뷰 정렬 (우선 순위: 2순위)
    #   - 긍정 확신도 낮은 순: Raw_Conf(긍정 확률)이 낮은 순서로 정렬
    df_pos_sorted = df_pos.sort_values(
        by="Raw_Conf",
        ascending=True,  # Raw_Conf(긍정 확률)이 낮을수록 약한 긍정 (오름차순)
    )

    # 5. 두 그룹을 합쳐 최종 DataFrame 생성 (부정 리뷰를 먼저 배치)
    df_sorted = pd.concat([df_neg_sorted, df_pos_sorted], ignore_index=True)

    # --- 정렬 로직 끝 ---

    st.dataframe(
        df_sorted[["Sentiment", "Confidence", "Keyword_Summary"]],
        use_container_width=True,
    )
