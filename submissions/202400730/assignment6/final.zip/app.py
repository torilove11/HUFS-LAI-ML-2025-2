import streamlit as st
import pandas as pd
import joblib
import os

# 1. 페이지 기본 설정 (제목, 아이콘)
st.set_page_config(page_title="Smart Drinking Coach", page_icon="🍺")

# 2. 제목 및 설명
st.title("🍺 Smart Drinking Coach")
st.write("오늘의 컨디션을 입력하면, **내일 숙취가 있을지** AI가 예측해 드립니다!")
st.divider()

# 3. 모델 로드 (캐싱을 사용해 속도 향상)
@st.cache_resource
def load_model():
    if os.path.exists('model.pkl'):
        return joblib.load('model.pkl')
    else:
        st.error("❌ 'model.pkl' 파일이 없습니다. 같은 폴더에 모델 파일을 넣어주세요.")
        return None

model = load_model()

# 모델이 있을 때만 화면 표시
if model:
    # 4. 사용자 입력 받기 (화면 구성)
    st.subheader("📝 오늘의 컨디션은?")
    
    col1, col2 = st.columns(2) # 화면을 2단으로 나누기
    
    with col1:
        sleep = st.number_input("어제 수면 시간 (시간)", min_value=0.0, max_value=24.0, value=7.0, step=0.5)
        stress = st.slider("현재 스트레스 지수 (1:좋음 ~ 10:나쁨)", 1, 10, 5)
        
    with col2:
        meal_option = st.radio("음주 전 식사 여부", ["안 함 (공복)", "식사 함"], index=1)
        meal = 1 if meal_option == "식사 함" else 0
    
    st.subheader("🍶 무엇을 마실까요?")
    drink_type = st.selectbox("주종 선택", ["Soju", "Beer", "Mix"])
    amount = st.number_input(f"마실 {drink_type} 양 (병 단위)", min_value=0.5, max_value=10.0, value=1.5, step=0.5)

    # 5. 예측 버튼
    if st.button("결과 확인하기", type="primary"):
        # 입력 데이터 정리
        input_data = pd.DataFrame({
            'sleep_hours': [sleep],
            'meal_before': [meal],
            'stress_level': [stress],
            'drink_type': [drink_type],
            'amount': [amount]
        })

        # AI 예측
        prediction = model.predict(input_data)[0]
        proba = model.predict_proba(input_data)[0][1] * 100 # 확률 계산

        st.divider()
        # 결과 보여주기
        if prediction == 1:
            st.error(f"🚨 **위험합니다! (숙취 확률: {proba:.1f}%)**")
            st.write(f"오늘 컨디션에 {drink_type} {amount}병은 무리입니다. 양을 줄이거나 물을 많이 드세요.")
        else:
            st.balloons() # 풍선 효과 🎉
            st.success(f"✅ **안전합니다! (숙취 확률: {proba:.1f}%)**")
            st.write("이 정도면 내일 상쾌하게 일어날 수 있겠네요. 즐거운 시간 되세요!")