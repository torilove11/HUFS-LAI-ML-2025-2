import torch
import torch.nn as nn
from transformers import AutoModel


class MultiHeadRoberta(nn.Module):
    def __init__(self, model_name="klue/roberta-small"):
        super().__init__()
        # 로컬 경로에 모델이 있으면 로컬 경로, 없으면 허깅페이스 다운로드
        self.roberta = AutoModel.from_pretrained(model_name)
        self.dropout = nn.Dropout(0.2)

        self.rel_classifier = nn.Linear(768, 2)  # 관련도 (0, 1)
        self.imp_classifier = nn.Linear(768, 3)  # 중요도 (0, 1, 2)

    def forward(self, input_ids, attention_mask=None, labels=None):
        outputs = self.roberta(input_ids=input_ids, attention_mask=attention_mask)

        if isinstance(outputs, tuple):
            last_hidden_state = outputs[0]
        else:
            last_hidden_state = outputs.last_hidden_state

        pooled_output = last_hidden_state[:, 0, :]
        pooled_output = self.dropout(pooled_output)

        logits_rel = self.rel_classifier(pooled_output)
        logits_imp = self.imp_classifier(pooled_output)

        return {"logits_rel": logits_rel, "logits_imp": logits_imp}
