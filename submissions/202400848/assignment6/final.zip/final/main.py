import torch
from transformers import AutoTokenizer
from my_model import MultiHeadRoberta
from crawler import crawl_latest
import notifier
import os
import sys
import datetime
import time

# 경로 설정
MODEL_PATH = "./model"
LOG_FILE = "execution_log.txt"


class Logger(object):
    def __init__(self):
        self.terminal = sys.stdout
        self.log = open(LOG_FILE, "a", encoding="utf-8")

    def write(self, message):
        self.terminal.write(message)
        self.log.write(message)
        self.log.flush()

    def flush(self):
        self.terminal.flush()
        self.log.flush()


sys.stdout = Logger()


def main():
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    print(f"\n\n========================================")
    print(f"[{now}] 실행 시작")
    print(f"========================================")

    if not os.path.exists(os.path.join(MODEL_PATH, "pytorch_model.bin")):
        print("오류: ./model 폴더에 가중치 파일이 없습니다.")
        return

    print("Loading AI Model (CPU)...")
    try:
        device = torch.device("cpu")
        tokenizer = AutoTokenizer.from_pretrained(MODEL_PATH)
        # 1. 원본 모델 구조 로드
        model = MultiHeadRoberta("klue/roberta-small")
        # 2. 내 가중치 덮어쓰기
        state_dict = torch.load(
            os.path.join(MODEL_PATH, "pytorch_model.bin"), map_location=device
        )
        model.load_state_dict(state_dict)
        model.to(device)
        model.eval()
        print("모델 로드 성공.")
    except Exception as e:
        print(f"모델 로드 오류: {e}")
        return

    try:
        new_notices = crawl_latest()
    except Exception as e:
        print(f"크롤링 오류: {e}")
        return

    if not new_notices:
        print(f"[{now}] 새로운 공지사항이 없습니다.")
        return

    print(f"분석할 공지사항: {len(new_notices)}개")

    email_queue = []

    for notice in new_notices:
        try:
            inputs = tokenizer(
                notice["text"],
                return_tensors="pt",
                truncation=True,
                max_length=512,
                padding="max_length",
            )

            with torch.no_grad():
                outputs = model(inputs["input_ids"], inputs["attention_mask"])
                pred_rel = torch.argmax(outputs["logits_rel"]).item()
                pred_imp = torch.argmax(outputs["logits_imp"]).item()

            is_fcfs = "선착순" in notice["text"]

            # 선착순이거나 중요도가 2(긴급)이면 is_urgent = True
            is_urgent = is_fcfs or pred_imp == 2

            print(f"-> [{notice['title']}] (중요도: {pred_imp})")

            # 날짜 추출
            extracted_date = notifier.extract_date_openai(notice["text"])
            if not extracted_date:
                extracted_date = notifier.extract_date_regex(notice["text"])

            today = datetime.date.today().isoformat()

            # === [로직 분기] ===

            # 1. 중요도 2 (가장 중요) 혹은 '선착순' 포함 -> 이메일 O, 노션 2번 등록
            if is_urgent:
                email_queue.append(
                    {
                        "title": notice["title"],
                        "link": notice["link"],
                        "content": notice["content"],
                        "is_fcfs": is_fcfs,
                    }
                )

                # 1. '2[공지]' 태그로 오늘 날짜에 무조건 등록
                notifier.add_to_notion(notice, "2[공지]", today)

                # 2. 마감일이 별도로 있으면 '2[마감]' 태그로 마감일에 추가 등록
                if extracted_date:
                    notifier.add_to_notion(notice, "2[마감]", extracted_date)

            # 2. 중요도 1 (중요) -> 이메일 X, 노션 O ('1')
            elif pred_imp == 1:
                # 날짜 있으면 그 날짜, 없으면 오늘 (하나만 등록)
                date_to_use = extracted_date if extracted_date else today
                notifier.add_to_notion(notice, "1", date_to_use)

            # 3. 중요도 0 (일반) -> 이메일 X, 노션 O ('0') - 날짜 없음
            else:
                notifier.add_to_notion(notice, "0", None)

        except Exception as e:
            print(f"   [Error] 처리 중 오류: {e}")
            continue

    # 4. 이메일 일괄 발송
    if email_queue:
        print(f"\n📨 총 {len(email_queue)}건의 중요 공지를 메일로 발송합니다.")
        notifier.send_email_bundle(email_queue)
    else:
        print("\n📭 발송할 중요 공지가 없습니다.")

    print(f"========================================")
    print(f"[{datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] 실행 종료")
    print(f"========================================\n")


if __name__ == "__main__":
    main()


# python main.py
