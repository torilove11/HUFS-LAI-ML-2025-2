import smtplib
from email.mime.text import MIMEText
from notion_client import Client
from openai import OpenAI
import re

# fmt: off
# ================= 사용자 설정 (여기를 채우세요) =================
EMAIL_ADDRESS = " "  # "본인의지메일@gmail.com"
EMAIL_PASSWORD = " "  # "여기에_앱비밀번호_16자리"
NOTION_TOKEN = " "  # "여기에_노션_시크릿토큰"
NOTION_DB_ID = " "  # "여기에_노션_데이터베이스_ID"
OPENAI_API_KEY = " "  # OPENAIAPI 키가 있다면 입력
# ===============================================================
# fmt: on


def extract_date_openai(text):
    """OpenAI gpt-4o-mini를 사용하여 '신청 마감일' 추출"""
    if not OPENAI_API_KEY:
        return None
    try:
        client = OpenAI(api_key=OPENAI_API_KEY)
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {
                    "role": "system",
                    "content": (
                        "당신은 공지사항 텍스트에서 '신청 마감일'을 추출하는 전문가입니다. 다음 규칙을 엄격하게 따르세요:\n"
                        "1. '모집 기간', '신청 마감', '제출 기한', '~' 뒤의 날짜 등 **신청이나 접수가 끝나는 날짜**를 식별하십시오.\n"
                        "2. '교육 기간', '활동 기간', '행사 일시' 등 **프로그램 자체의 시작일이나 기간은 엄격하게 무시**하십시오.\n"
                        "3. 날짜가 범위(예: 2025.12.01 ~ 2025.12.07)로 제공되면 **종료일(2025-12-07)을 선택**하십시오.\n"
                        "4. 'YYYY-MM-DD' 형식의 **날짜 하나만** 출력하십시오.\n"
                        "5. 신청 마감일이 발견되지 않으면 'None'을 반환하십시오."
                    ),
                },
                {"role": "user", "content": text},
            ],
            temperature=0,
        )
        result = response.choices[0].message.content.strip()
        if "None" in result:
            return None
        return result
    except Exception as e:
        print(f"   [Error] OpenAI 호출 오류: {e}")
        return None


def extract_date_regex(text):
    match = re.search(
        r"202[4-6][-./](0[1-9]|1[0-2])[-./](0[1-9]|[12][0-9]|3[01])", text
    )
    if match:
        return match.group().replace(".", "-").replace("/", "-")
    return None


def send_email_bundle(notice_list):
    """
    여러 공지를 하나의 메일로 묶어서 발송
    notice_list: [{"title":..., "link":..., "content":..., "is_fcfs":True/False}, ...]
    """
    if not notice_list:
        return

    subject = f"[학교 공지 알림] 중요 공지 {len(notice_list)}건 도착"

    body = f"총 {len(notice_list)}건의 중요 공지가 있습니다.\n\n"
    for item in notice_list:
        prefix = "[선착순]" if item["is_fcfs"] else "[중요]"
        body += f"========================================\n"
        body += f"{prefix} {item['title']}\n"
        body += f"링크: {item['link']}\n"
        body += f"내용 미리보기:\n{item['content'][:300]}...\n"
        body += "\n"

    try:
        msg = MIMEText(body)
        msg["Subject"] = subject
        msg["From"] = EMAIL_ADDRESS
        msg["To"] = EMAIL_ADDRESS

        with smtplib.SMTP_SSL("smtp.gmail.com", 465) as server:
            server.login(EMAIL_ADDRESS, EMAIL_PASSWORD)
            server.send_message(msg)
        print(f"📧 통합 이메일 발송 완료 ({len(notice_list)}건)")
    except Exception as e:
        print(f"이메일 전송 실패: {e}")


def add_to_notion(notice, tag_name, date=None):
    """
    tag_name: "2[마감]", "2[공지]", "1", "0" 중 하나
    date: None이면 캘린더에 안 뜨고 리스트에만 남음
    """
    try:
        notion = Client(auth=NOTION_TOKEN)

        properties = {
            "제목": {"title": [{"text": {"content": notice["title"]}}]},
            "링크": {"url": notice["link"]},
            "중요도": {"multi_select": [{"name": tag_name}]},
        }

        # 날짜가 있을 때만 속성에 추가
        if date:
            properties["마감일"] = {"date": {"start": date}}

        notion.pages.create(parent={"database_id": NOTION_DB_ID}, properties=properties)
        print(f"📅 노션 등록 완료: [{tag_name}] {notice['title']}")

    except Exception as e:
        print(f"노션 등록 실패: {e}")
