# 🤖 c.ai Translator (Personalized Ko-En Translator)

**c.ai Translator**는 character.ai의 채팅 구조와 저 유연주의 문체를 학습한 파인튜닝 모델을 기반으로, 한국어 문장을 영어 문장으로 번역해주는 웹 서비스입니다.
Hugging Face에 업로드된 `pilan2/cai-translator` 모델을 로드하여 추론하며, Gradio를 통해 직관적인 웹 인터페이스를 제공합니다.

## 📌 주요 기능
- **채팅 구조 반영:** c.ai의 채팅 구조를 반영하여, 대사를 제외한 지시문을 자동으로 인식하여 asterisk(`*`)를 지시문의 양 끝에 추가합니다.
- **개인화 번역:** 단순 직역이 아닌, 제 문체가 반영된 영어 번역을 제공합니다.
- **웹 인터페이스:** Gradio를 활용하여 별도의 설치 없이 브라우저에서 바로 번역기를 사용할 수 있습니다.

## 🚀 설치 및 실행 방법 (Installation & Usage)
깃허브에 업로드할 것처럼 파일을 구성해뒀지만 일단 당장은 올리지 않을 것이기에 저장소 클론은 넘어갑니다...
### 1. 환경 설정
```
pip install -r requirements.txt
```
### 2. 서비스 실행
```
python app.py
```
### 3. 웹 접속
브라우저에서 `http://127.0.0.1:7860`에 접속하여 시스템을 사용할 수 있습니다.

## 🛠️ 모델 정보
- **Base Model:** Helsinki-NLP/opus-mt-ko-en
- **Fine-tuned Model:** pilan2/cai-translator