import gradio as gr
from transformers import AutoTokenizer, AutoModelForSeq2SeqLM

# 모델 로드
model_path = "pilan2/cai-translator"

print(f"Loading model from {model_path}...")
tokenizer = AutoTokenizer.from_pretrained(model_path)
model = AutoModelForSeq2SeqLM.from_pretrained(model_path)

# 추론 함수
def translate_to_my_style(korean_text):

    inputs = tokenizer(korean_text, return_tensors="pt", max_length=128, truncation=True)

    outputs = model.generate(
        **inputs,
        max_length=128,
        num_beams=5,
        early_stopping=True,
        no_repeat_ngram_size=2,
    )

    decoded_output = tokenizer.decode(outputs[0], skip_special_tokens=True)
    return decoded_output

# 웹 인터페이스
iface = gr.Interface(
    fn=translate_to_my_style,
    inputs="text",
    outputs="text",
    title="character.ai Translator",
    description="한국어 문장을 입력하면 제 문체의 영어 문장으로 번역됩니다."
)

# 실행 (링크 생성)
iface.launch()