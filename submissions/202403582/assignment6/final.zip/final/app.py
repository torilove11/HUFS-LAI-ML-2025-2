
import gradio as gr
import joblib
import re
import numpy as np
import os
from sklearn.metrics import f1_score


# 현재 파일(app.py)이 위치한 폴더 경로를 찾기
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# 그 폴더 안에 있는 model 폴더와 파일명을 합치기
MODEL_PATH = os.path.join(BASE_DIR, "model", "final_model.pkl")
TFIDF_PATH = os.path.join(BASE_DIR, "model", "tfidf_vectorizer.pkl")

# 만들어진 절대 경로로 파일을 불러오기
model = joblib.load(MODEL_PATH)
tfidf = joblib.load(TFIDF_PATH)


# 전처리 함수
stopwords = set([
    # 1) filler / 말버릇
    "어", "음", "자", "뭐", "요", "네", "막", "그냥",
    "근데", "그죠", "거죠", "예",

    # 2) 지시어
    "이거", "이게", "이건", "그거", "그게",
    "저거", "요거", "요게", "얘는",

    # 3) 공손/형식적 표현
    "합니다", "되었습니다", "됩니다", "하겠습니다",
    "해주세요", "드릴", "보겠습니다", "할게요",
    "있습니다", "있어요", "있죠",

    # 4) 기능어
    "이", "그", "저", "을", "를", "은", "는", "에",
    "에서", "로", "것", "거", "건", "것들",
])

def preprocess(text):
    text = str(text).lower()
    text = re.sub(r"[^가-힣a-zA-Z0-9\s]", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    tokens = [t for t in text.split() if t not in stopwords]
    return " ".join(tokens)


# 문장 분리(입력 방식 기준)
def split_sentences(text):
    sentences = re.split(r'(?<=[.!?])\s+', text.strip())
    return [s.strip() for s in sentences if s.strip()]


# 핵심 문장 추출 + 정렬 기능
def extract_key_sentences(text, threshold, sort_mode):

    sentences = split_sentences(text)
    if len(sentences) == 0:
        return "<p>문장을 찾을 수 없습니다.</p>"

    clean_list = [preprocess(s) for s in sentences]
    vec = tfidf.transform(clean_list)
    probs = model.predict_proba(vec)[:, 1]
    preds = (probs >= threshold).astype(int)

    items = []
    for i, (s, p, pr) in enumerate(zip(sentences, preds, probs)):
        items.append({
            "sentence": s,
            "prob": float(pr),
            "is_key": int(p),
            "index": i
        })

    # ---------------- Sorting ----------------
    if sort_mode == "원래 순서":
        items.sort(key=lambda x: x["index"])
    elif sort_mode == "핵심문장 먼저":
        items.sort(key=lambda x: x["is_key"], reverse=True)
    elif sort_mode == "확률 높은 순":
        items.sort(key=lambda x: x["prob"], reverse=True)
    elif sort_mode == "확률 낮은 순":
        items.sort(key=lambda x: x["prob"])

    # ---------------- HTML 구성 ----------------
    html = ""
    for c in items:
        if c["is_key"] == 1:
            bg = "#c5efb9"
            label = "<b style='color:#0b4619'>🌟 핵심 문장</b>"
            text_color = "black"
        else:
            bg = "#2c2c2c"
            label = "<b style='color:white'>일반 문장</b>"
            text_color = "white"

        html += f"""
        <div style='padding:14px; margin:10px 0; background:{bg}; border-radius:10px;'>
            {label}<br>
            <div style="margin-top:6px; color:{text_color};">{c['sentence']}</div>
            <div style="font-size:12px; color:#444;">확률: {c['prob']:.4f}</div>
        </div>
        """

    return html


# KEYWORD 추출(문장별 TF-IDF sum 방식)
def extract_keywords(text, top_k):
    sentences = split_sentences(text)
    if len(sentences) == 0:
        return "<p>문장이 없어 키워드를 추출할 수 없습니다.</p>"

    clean_list = [preprocess(s) for s in sentences]
    vec = tfidf.transform(clean_list)

    scores = vec.sum(axis=0).A1
    feature_names = np.array(tfidf.get_feature_names_out())

    sorted_idx = np.argsort(scores)[::-1]
    top_words = feature_names[sorted_idx][:top_k]
    top_scores = scores[sorted_idx][:top_k]

    html = "<h4>🔑 주요 키워드</h4>"
    for w, sc in zip(top_words, top_scores):
        html += f"<div>• {w} <span style='color:#666'>({sc:.4f})</span></div>"

    return html


# 자동 threshold 최적화(+설명)
def auto_threshold(text):

    sentences = split_sentences(text)
    if len(sentences) == 0:
        return "문장이 없음", 0.06

    clean_list = [preprocess(s) for s in sentences]
    vec = tfidf.transform(clean_list)
    probs = model.predict_proba(vec)[:, 1]

    pseudo_labels = (probs > np.median(probs)).astype(int)

    thresholds = np.linspace(0.01, 0.25, 50)
    best_thr, best_f1 = 0.06, -1

    for thr in thresholds:
        preds = (probs >= thr).astype(int)
        f1 = f1_score(pseudo_labels, preds)
        if f1 > best_f1:
            best_thr = thr
            best_f1 = f1

    msg = (
        f"📈 추천 threshold: <b>{best_thr:.4f}</b><br>"
        f"(입력 텍스트 내부 확률 분포 기반 local-threshold)"
    )
    return msg, float(best_thr)

# Keyword 방식 설명 함수
def explain_keyword_method():
    html = """
    <h3>🔍 Keyword 추출 방식 설명</h3>
    Keyword는 문서 전체를 문장 단위로 TF-IDF로 변환한 뒤,<br>
    각 문장의 TF-IDF 벡터를 모두 합산하여 점수가 높은 단어를 상위 N개 선택합니다.<br><br>
    즉,<br>
    - 자주 등장하고,<br>
    - 특정 문장에서 상대적으로 중요도가 높은 단어일수록<br>
    더 높은 점수를 갖게 됩니다.<br><br>
    이 방식은 TextRank보다 단순하지만,<br>
    강의 텍스트처럼 주제가 뚜렷한 문서에서는 안정적으로 중요한 용어를 뽑아냅니다.
    """
    return html

# 자동 노트 생성 함수
def generate_note(text, threshold, top_k):
    sentences = split_sentences(text)
    if len(sentences) == 0:
        return "<p>노트를 생성할 수 없습니다. 문장이 없습니다.</p>"

    # --- 키워드 ---
    clean_list = [preprocess(s) for s in sentences]
    vec = tfidf.transform(clean_list)
    scores = vec.sum(axis=0).A1
    feature_names = np.array(tfidf.get_feature_names_out())
    idx = np.argsort(scores)[::-1][:top_k]
    keywords = feature_names[idx]

    # --- 핵심 문장 ---
    probs = model.predict_proba(vec)[:, 1]
    key_sents = [s for s, p in zip(sentences, probs) if p >= threshold]

    # --- 요약문 ---
    summary = " ".join(key_sents) if len(key_sents) > 0 else "핵심 문장이 부족하여 요약을 생성하지 못했습니다."

    # --- HTML 생성 ---
    html = "<h2>📒 자동 생성 노트</h2>"

    html += "<h3>🔑 핵심 키워드</h3><ul>"
    for w in keywords:
        html += f"<li>{w}</li>"
    html += "</ul>"

    html += "<h3>🌟 핵심 문장</h3><ul>"
    for s in key_sents:
        html += f"<li>{s}</li>"
    html += "</ul>"

    html += f"<h3>📝 요약문</h3><p>{summary}</p>"

    return html

# 핵심문장 판단 기준 설명 함수
def explain_key_sentence_method():
    html = """
    <h3>🌟 핵심 문장 판단 기준 설명</h3>
    본 모델은 <b>Logistic Regression</b>을 사용하여 각 문장이 핵심 문장일 확률을 계산합니다.<br><br>

    핵심 문장 판단은 다음 기준을 따릅니다:<br>
    <ul>
        <li>TF-IDF로 변환된 문장을 입력으로 사용</li>
        <li>모델이 각 문장에 대해 <b>확률 p(핵심문장)</b>을 계산</li>
        <li>p ≥ threshold → 핵심 문장</li>
        <li>p < threshold → 일반 문장</li>
    </ul>

    즉, threshold 값에 따라 선택되는 핵심 문장 개수가 달라집니다.<br>
    확률이 높을수록 강의의 핵심 내용을 담고 있을 가능성이 높다고 해석할 수 있습니다.
    """
    return html


# threshold 기준 설명 함수
def explain_threshold_method():
    html = """
    <h3>📉 Threshold 기준 설명</h3>
    Threshold는 모델이 예측한 확률을 기반으로,<br>
    <b>어디까지를 핵심 문장으로 인정할지 결정하는 기준값</b>입니다.<br><br>

    <b>threshold가 낮을 때:</b><br>
    - 더 많은 문장이 핵심으로 선택됨<br>
    - 핵심이 넓게 잡혀 요약이 길어질 수 있음<br><br>

    <b>threshold가 높을 때:</b><br>
    - 정말 중요한 문장만 선택됨<br>
    - 요약은 짧아지고 핵심성이 올라감<br><br>

    🔧 <b>자동 threshold 기능</b>은 입력된 문장들의 분포를 분석하여<br>
    최적의 threshold를 계산해 추천합니다.
    """
    return html


# UI 구성
with gr.Blocks(
    title="강의자료 자동 요약기",
    css="""
    .input-textbox textarea {
        font-size: 18px !important;
        line-height: 1.5 !important;
    }
    .output-html {
        font-size: 17px !important;
        line-height: 1.6 !important;
    }
    """
) as demo:

    gr.Markdown("""
    <div style='text-align:center; padding: 10px 0;'>
        <h1>📘 강의자료 자동 요약기</h1>
        <h3 style='color:#4c8bf5'>TF-IDF + LogRegression 기반 핵심 문장 추출 모델</h3>
        <p style='color:#777; font-size:16px'>
            컴퓨터/AI 분야 강의 텍스트를 입력하면, 핵심 문장/키워드/threshold 추천 값을 자동으로 분석합니다.
        </p>
        <hr>
    </div>
    """)

    with gr.Row():

        # ---------------- LEFT ----------------
        with gr.Column(scale=1):

            text_input = gr.Textbox(
                label="강의 텍스트 입력",
                placeholder="문장 끝에 . ! ? 를 붙여 입력하세요.",
                lines=15,
                elem_classes=["input-textbox"]
            )

            example_btn = gr.Button("📌 예시 불러오기", variant="secondary")

            gr.Markdown("### 🔧 요약 옵션")

            threshold = gr.Slider(0.01, 0.20, value=0.06, label="Threshold (핵심문장 판단 기준)")
            sort_mode = gr.Dropdown(
                ["원래 순서", "핵심문장 먼저", "확률 높은 순", "확률 낮은 순"],
                value="핵심문장 먼저",
                label="정렬 방식"
            )

            run_btn = gr.Button("🔍 핵심 문장 추출", variant="primary")

            gr.Markdown("### 🔑 Keyword 추출")
            keyword_k = gr.Slider(3, 20, value=10, label="키워드 개수")
            keyword_btn = gr.Button("✨ 키워드 추출하기", variant="secondary")

            gr.Markdown("### 📈 자동 threshold 계산")
            thr_btn = gr.Button("⚙️ threshold 자동 최적화", variant="secondary")

            gr.Markdown("### 📘 추가 기능")

            note_btn = gr.Button("📒 자동 노트 생성")
            key_sentence_info_btn = gr.Button("🌟 핵심문장 기준 설명")
            keyword_info_btn = gr.Button("🔍 키워드 방식 설명")
            threshold_info_btn = gr.Button("📉 Threshold 기준 설명")



        # ---------------- RIGHT ----------------
        with gr.Column(scale=1):

            note_html = gr.HTML(label="자동 노트")
            key_sentence_info_html = gr.HTML(label="핵심문장 기준 설명")
            keyword_info_html = gr.HTML(label="Keyword 설명")
            threshold_info_html = gr.HTML(label="Threshold 설명")


            gr.Markdown("## 📄 핵심 문장 결과")
            output_html = gr.HTML(elem_classes=["output-html"])

            gr.Markdown("## 🔑 키워드 결과")
            keyword_html = gr.HTML(elem_classes=["output-html"])

            gr.Markdown("## 📉 threshold 추천값")
            thr_html = gr.HTML(elem_classes=["output-html"])

    # 이벤트 연결
    example_text = """이번 시간에는 크루스칼 알고리즘을 다루어 보겠습니다.
    크루스칼 알고리즘은 가장 적은 비용으로 모든 노드를 연결하기 위해 사용하는 알고리즘입니다.
    다시 말해 최소 비용 신장 트리를 만들기 위한 알고리즘입니다.
    단순하게 모든 노드를 하나로 연결하도록 만들되, 가장 적은 비용을 사용하는 것이 목표입니다.
    여러 도시가 있을 때, 각 도시를 도로로 연결할 때 최소 비용으로 연결하고자 한다면 적용할 수 있는 알고리즘입니다.
    먼저 그래프 이론의 기본 용어를 정리해 보겠습니다.
    노드는 정점과 같은 의미입니다.
    도시, 건물 같은 대상 하나하나를 노드라고 합니다.
    그래프에서 동그라미로 표현되는 부분입니다.
    간선은 그래프에서 선으로 표현되는 부분입니다.
    거리라고도 하고 비용이라고도 부릅니다.
    이 예시는 총 7개의 노드가 있고, 11개의 간선이 존재하는 그래프입니다.
    이제 이 상황에서 크루스칼 알고리즘의 핵심은 무엇일까요?
    간단합니다.
    각 노드를 전부 연결한다고 생각해 봅시다.
    예를 들어 이런 식으로 연결하면 총 6개의 간선을 사용하여 모든 노드를 연결할 수 있습니다.
    즉 노드가 7개라면, 모든 노드를 연결하기 위해 필요한 간선의 개수는 항상 노드 개수에서 1을 뺀 값입니다.
    이제 최소 비용 신장 트리를 구하는 방법을 살펴보겠습니다.
    크루스칼 알고리즘의 핵심 개념은 간선을 거리가 짧은 순서대로 그래프에 포함시키는 것입니다.
    즉 모든 간선을 오름차순으로 정렬한 뒤에, 가장 비용이 적은 간선부터 순서대로 선택합니다.
    하지만 주의할 점은 사이클이 발생하면 안 된다는 것입니다.
    3개 이상의 노드가 서로 연결되어 순환 구조가 생기면 사이클입니다.
    최소 비용 신장 트리에서는 사이클을 만들 이유가 없으므로 사이클을 만드는 간선은 포함시키지 않습니다.
    정렬된 간선들을 보면서, 비용이 12인 간선을 먼저 선택합니다.
    그다음 비용이 13인 간선을 선택합니다.
    그다음 비용이 17, 20, 24 순서로 선택합니다.
    비용이 28인 간선을 선택하려고 하면 사이클이 발생하므로 제외합니다.
    그다음 비용이 37인 간선을 포함하면 7개의 노드가 모두 연결됩니다.
    이렇게 총 6개의 간선으로 최소 비용 신장 트리가 만들어집니다.
    이제 이를 코드로 구현해 보면 그대로 크루스칼 알고리즘이 됩니다.
    간선의 개수가 11개라면 각 간선의 정보를 하나의 데이터로 묶어야 합니다.
    예를 들어, 1과 7이 12의 비용으로 연결되어 있다고 표현하고, 이런 데이터를 11개 정의합니다.
    이제 간선들을 오름차순으로 정렬합니다.
    그 다음 각 노드가 어떤 집합에 포함되어 있는지 저장하는 부모 테이블을 만듭니다.
    초기에는 모든 노드가 자기 자신을 부모로 가지도록 설정합니다.
    이제 정렬된 간선들을 하나씩 보면서, 사이클이 발생하지 않으면 해당 간선을 선택하고, 사이클이 발생하면 선택하지 않습니다.
    이 과정을 반복하면 최소 비용 신장 트리를 만들 수 있습니다.
    이 예시에서는 결과 비용이 123으로 계산됩니다.
    이렇게 크루스칼 알고리즘은 가장 적은 비용으로 모든 정점을 연결할 때 사용하는 매우 중요한 알고리즘입니다.
    알고리즘 문제에서도 자주 출제되므로 반드시 공부해 두는 것이 좋습니다. """

    example_btn.click(lambda: example_text, outputs=text_input)

    run_btn.click(
        extract_key_sentences,
        inputs=[text_input, threshold, sort_mode],
        outputs=output_html
    )

    text_input.submit(
        extract_key_sentences,
        inputs=[text_input, threshold, sort_mode],
        outputs=output_html
    )

    keyword_btn.click(
        extract_keywords,
        inputs=[text_input, keyword_k],
        outputs=keyword_html
    )

    thr_btn.click(
        auto_threshold,
        inputs=text_input,
        outputs=[thr_html, threshold]
    )

    note_btn.click(
        generate_note,
        inputs=[text_input, threshold, keyword_k],
        outputs=note_html
    )

    key_sentence_info_btn.click(
        explain_key_sentence_method,
        inputs=None,
        outputs=key_sentence_info_html
    )

    keyword_info_btn.click(
        explain_keyword_method,
        inputs=None,
        outputs=keyword_info_html
    )

    threshold_info_btn.click(
        explain_threshold_method,
        inputs=None,
        outputs=threshold_info_html
    )

    gr.Markdown("""
    <div style='text-align:center; padding:20px 0 10px 0; color:#888; font-size:13px;'>
        <u>Credit: 본 프로젝트의 일부 과정에서 생성형 AI를 활용하였음을 밝힙니다.</u>
    </div>
    """)

if __name__ == "__main__":
  demo.launch()
